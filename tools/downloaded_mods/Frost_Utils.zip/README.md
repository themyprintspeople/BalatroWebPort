## Frost's Util

Balatro mod for optimization & some utility.

- Reduces loading time (including SMODS)
- EV2 for handing large event queues & score faster
- Async scoring, letting animtions run while also calculate
- FPS improvement with update parallelization & reduction
- More