--- @class futil.config.initstate
local ConfigInit = {}

function ConfigInit.create()
	--- @type futil.Settings
	return {
		customgc = {
			enable = true,
			interval = 30,
			boostMin = 150,
			boostMult = 8,
			baseStep = 2
		},
		ev2 = {
			enable = true,
			acceleration = 8,
			frequency = 120
		},
		asyncScoring = {
			er = false,
			gfep = false,
			debugtrace = false
		},
		reductions = {
			card = {
				enable = false,
				rate = 4,
			},
			controller = {
				enable = true,
				idleFreq = 1,
				activeFreq = 20,
			},
			dynatext = {
				enable = true,
				rate = 3,
				minAge = 1
			},
			uie = {
				enable = false,
				rate = 4,
			}
		},
		shaderReduction = 0,
		jit = 1,
	}
end

local function deepassign(dest, src)
	if dest == nil then return src end
	if type(dest) ~= "table" or type(src) ~= "table" then return dest end

	for k,v in pairs(src) do
		dest[k] = deepassign(dest[k], v)
	end
	return dest
end

function ConfigInit.init()
	G.SETTINGS.futil = deepassign(G.SETTINGS.futil, ConfigInit.create())
end

return ConfigInit