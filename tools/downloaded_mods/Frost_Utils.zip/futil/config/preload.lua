--- @class futil.config.preload
--- @field config futil.config.preload.config
local conf = {
	config = {}
}

function conf.save()
	local str = {}
	for k,v in pairs(conf.config) do
		table.insert(str, string.format('%s = %s\n', k, v))
	end
	table.sort(str)
	love.filesystem.createDirectory('config')
	love.filesystem.write('config/futil_pre.txt', table.concat(str))
end

function conf.load()
	local dok, lines = pcall(love.filesystem.lines, 'config/futil_pre.txt')
	if not dok then return end

	for line in lines do
		local k, v = line:match("^([%w_]+)%s*=%s*(.*)")
		if k and v then
			conf.config[k] = v
		end
	end
end

function conf.setBoolean(k, v)
	conf.config[k] = v and '' or nil
end

conf.load()

return conf