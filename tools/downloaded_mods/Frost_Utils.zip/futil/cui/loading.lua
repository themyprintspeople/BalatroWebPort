local uiutil = require("futil.cui.util")
local preload = require("futil.config.preload")

--- @class futil.cui.loading
local ui = {
	opts = {
		disableModules = {
			{ 'math', 'physics', 'touch', 'video', 'joystick' },
		}
	},
	funcs = {
		openConfig = 'futil_open_config',
		clearCache = 'futil_clearcache',
		generateDump = 'futil_gendump'
	}
}

--- @param module string
function ui.disableModuleToggle(module)
	return create_toggle({
		label = module,
		ref_table = preload.config,
		ref_value = 'disable_' .. module,
		callback = function (value)
			if not value then require("love."..module) end
			preload.setBoolean('disable_' .. module, value)
			preload.save()
		end,
		col = true,
		w = 1.35,
	})
end

function ui.title(text)
	--- @type balatro.UIElement.Definition
	return { n = G.UIT.R, config = {align = 'cm', padding = 0.1}, nodes = {{ n = G.UIT.T, config = { text = text, scale = 0.5 } }} }
end

function ui.warning(texts)
	local nodes = {}
	for i, v in ipairs(texts) do
		table.insert(nodes, {
			n = G.UIT.R, config = {align = 'cm'}, nodes = {{ n = G.UIT.T, config = { text = v, scale = 0.3, colour = G.C.YELLOW } }}
		})
	end

	--- @type balatro.UIElement.Definition
	return { n = G.UIT.R, config = {align = 'cm', padding = 0.1}, nodes = {{ n = G.UIT.C, nodes = nodes }} }
end

function ui.disabledModules()
	--- @type balatro.UIElement.Definition[]
	local elms = {
		ui.title('Disabled Love2D modules'),
		ui.warning({
			'Disabling Love2D modules can make',
			'the game loads faster. However, some mods',
			'will require it, and can cause crashes instead',
		}),
	}

	for i,modules in ipairs(ui.opts.disableModules) do
		--- @type balatro.UIElement.Definition[]
		local row = {}
		for i, mod in ipairs(modules) do
			table.insert(row, ui.disableModuleToggle(mod))
		end
		table.insert(elms, { n = G.UIT.R, config = {align = 'cm'}, nodes = row })
	end

	return elms
end

function ui.buttons()
	local btns = {}
	for i,v in ipairs(ui.buttonArrays) do
		btns[i] = UIBox_button(v)
	end
	return btns
end

--- @type balatro.UI.ButtonParam[]
ui.buttonArrays = {
	{
		label = {'Clear cache'},
		button = ui.funcs.clearCache,
		col = true
	},
	{
		label = {'Generate dump'},
		button = ui.funcs.generateDump,
		col = true
	},
	{
		label = {'Open Config'},
		button = ui.funcs.openConfig,
		col = true
	},
}

--- @type futil.cui.util.Gen[]
ui.array = {
	ui.disabledModules,
	ui.buttons
}

function ui.main()
	return uiutil.root(uiutil.colGen(ui.array, true, true))
end

G.FUNCS[ui.funcs.clearCache] = function ()
	for i,v in ipairs(love.filesystem.getDirectoryItems('futil_lovelycache')) do
		love.filesystem.remove('futil_lovelycache/'..v)
	end
end

G.FUNCS[ui.funcs.openConfig] = function ()
	love.system.openURL('file:///'..love.filesystem.getSaveDirectory()..'/config/futil_pre.txt')
end

ui.gendumpcode = [[
local files = ...
require"love.filesystem"
for i, file in ipairs(files) do
	loadstring(assert(love.filesystem.read(file)), "@"..file)
end
]]

G.FUNCS[ui.funcs.generateDump] = function ()
	love.thread.newThread(ui.gendumpcode):start(require("futil.quickpatch").files)
end

return ui