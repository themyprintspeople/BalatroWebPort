local uiutil = require("futil.cui.util")
local preload = require("futil.config.preload")

--- @class futil.cui.main
local ui = {
	opts = {
		jit = {'Auto', 'On', 'Off'},
		shaders = {'None', 'Partial', 'All'},
		shaderValues = {0, 1, 2}
	}
}

function ui.asyncScoring()
	local scoring_tip = {
		"Scores jokers on the backgruond",
		"while the animation is running.",
		"Requires Event V2 to be turned on.",
	}
	local conf = G.SETTINGS.futil
	--- @type balatro.UIElement.Definition[]
	return {
		uiutil.gtitle('Async Scoring'),
		uiutil.splitter(),

		uiutil.toggle({
			label = 'Scoring',
			ref_table = conf.asyncScoring,
			ref_value = 'gfep',
			tooltip = { text = scoring_tip }
		}),

		uiutil.toggle({
			label = 'End Round',
			ref_table = conf.asyncScoring,
			ref_value = 'er',
			tooltip = { text = scoring_tip }
		}),

		uiutil.toggle({
			label = 'Debug',
			ref_table = conf.asyncScoring,
			ref_value = 'debugtrace',
			tooltip = { text = {
				'Allows stacktrace to refer',
				'to the scoring when crash.',
			} }
		}),
	}
end

function ui.parallelMove()
	--- @type balatro.UIElement.Definition[]
	return {
		uiutil.toggle({
			label = 'Parallel UI',
			ref_table = preload.config,
			ref_value = 'parallel_move',
			callback = function (value)
				preload.config.parallel_move = value and '' or nil
				preload.save()
			end,
			tooltip = { text = {
				'Defers UI positioning updates to a thread.',
				'Enabling any of these will improve framerate, but can cause UI',
				'issues / crash and potentially incompat with another mod.',
			} },
		}),

		uiutil.splitter(),

		uiutil.toggle({
			label = 'Card Alignment',
			ref_table = preload.config,
			ref_value = 'parallel_align',
			tooltip = { text = {
				'Card positioning to card area',
				'Requires Parallel Moveable',
			} },
			callback = function (value)
				preload.config.parallel_align = value and '' or nil
				preload.save()
			end,
			w = 3
		}),

		uiutil.toggle({
			label = 'Controller',
			ref_table = preload.config,
			ref_value = 'parallel_controller',
			tooltip = { text = {
				'Hovering & collision UI effects.',
				'Requires Parallel Moveable',
			} },
			callback = function (value)
				preload.config.parallel_controller = value and '' or nil
				preload.save()
			end,
			w = 3
		})
	}
end

function ui.otherGen()
	local flush = UIBox_button({
		label = {'Flush JIT'},
		button = 'futil_jit_flush',
		scale = 0.4,
		minh = 0.6
	})
	flush.config.tooltip = {text = {
		'Flush compiled JIT code.'
	}}

	local conf = G.SETTINGS.futil
	--- @type balatro.UIElement.Definition[]
	return {
		uiutil.gtitle('Other'),
		uiutil.splitter(),

		uiutil.cycle({
			label = 'Shader Reduction',
			options = ui.opts.shaders,
			values = ui.opts.shaderValues,
			ref_table = conf,
			ref_value = 'shaderReduction',
			tooltip = { text = {
				'None - Allows ALL',
				'Partial - Skips some',
				'All - Skips ALL'
			} }
		}),

		uiutil.cycle({
			label = 'Jit Mode',
			options = ui.opts.jit,
			current_option = conf.jit,
			tooltip = { text = {
				'Just in time compiler.',
				'Performance impact may vary.',
				'Auto mode depends on the initial JIT status.'
			} },
			onCycle = function (cycle)
				G.SETTINGS.futil.jit = cycle.to_key
				if cycle.to_key == 2 and not jit.status() then
					jit.on()
					print('JIT turned on')
				elseif cycle.to_key == 3 and jit.status() then
					jit.off()
					print('JIT turned off')
				end
			end
		}),
		flush
	}
end

--- @type futil.cui.util.Gen[]
ui.array = {
	ui.asyncScoring,
	ui.parallelMove,
	ui.otherGen,
}

function ui.main()
	return uiutil.rootCols(ui.array)
end

function G.FUNCS.futil_jit_flush()
	return jit.flush()
end

return ui