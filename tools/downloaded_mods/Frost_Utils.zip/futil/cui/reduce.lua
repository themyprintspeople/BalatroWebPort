local uiutil = require("futil.cui.util")

--- @class futil.cui.reduce
local ui = {
	opts = {
		toggleWidth = 1.8,

		--- @type futil.cui.util.CycleParam
		rate = {
			label = 'Reduction',
			options = { 2, 3, 4, 6 },
			ref_value = 'rate',
			w = 1.6,
			tooltip = { text = {
				'How much update reduction to apply.',
				'e.g. 2 = updates every 2 frames'
			} }
		},
		--- @type futil.cui.util.CycleParam
		age = {
			label = 'Min age',
			options = { '0.25s', '0.5s', '0.75s', '1s' },
			values = { 0.25, 0.5, 0.75, 1 },
			ref_value = 'minAge',
			w = 1.6,
			tooltip = { text = {
				'Minimum object age to apply update reduction.',
				'e.g. 0.25s = 0.25s after object has been created'
			} }
		},
		controller = {
			activeOptions = { 30, 20, 15, 10 },
			idleOptions = { 3, 2, 1 }
		}
	}
}

--- @param which string
--- @param label? string
function ui.genericToggle(which, label)
	label = label or which
	return uiutil.toggle({
		label = label,
		ref_table = G.SETTINGS.futil.reductions[which],
		ref_value = 'enable',
		w = ui.opts.toggleWidth,
		col = true
	})
end

--- @param which string
function ui.genericRate(which)
	return { n = G.UIT.C, nodes = { uiutil.cycle( setmetatable({ ref_table = G.SETTINGS.futil.reductions[which] }, { __index = ui.opts.rate }) ) } }
end

--- @param which string
function ui.genericMinAge(which)
	return { n = G.UIT.C, nodes = { uiutil.cycle( setmetatable({ ref_table = G.SETTINGS.futil.reductions[which] }, { __index = ui.opts.age }) ) } }
end

--- @class futil.cui.reduce.genericopts
--- @field label? string
--- @field noRate? boolean
--- @field age? boolean

--- @param which string
--- @param opts? futil.cui.reduce.genericopts
function ui.generic(which, opts)
	opts = opts or {}

	local n = {}
	do
		table.insert(n, ui.genericToggle(which, opts.label))
	end
	if not opts.noRate then
		table.insert(n, ui.genericRate(which) or nil)
	end
	if opts.age then
		table.insert(n, ui.genericMinAge(which) or nil)
	end

	--- @type balatro.UIElement.Definition
	return { n = G.UIT.R, nodes = n }
end

function ui.controller()
	--- @type balatro.UIElement.Definition
	return { n = G.UIT.R, nodes = {
		ui.genericToggle('controller'),

		{ n = G.UIT.C, nodes = { uiutil.cycle({
			label = 'Idle Rate',
			options = ui.opts.controller.idleOptions,
			ref_table = G.SETTINGS.futil.reductions.controller,
			ref_value = 'idleFreq',
			w = ui.opts.rate.w,
			tooltip = {
				text = {
					'How frequent the controller should',
					'update when mouse IS NOT moved'
				}
			}
		}) } },

		{ n = G.UIT.C, nodes = { uiutil.cycle({
			label = 'Active Rate',
			options = ui.opts.controller.activeOptions,
			ref_table = G.SETTINGS.futil.reductions.controller,
			ref_value = 'activeFreq',
			w = ui.opts.age.w,
			tooltip = {
				text = {
					'How frequent the controller should',
					'update when mouse IS moved'
				}
			}
		}) } },
	} }
end

function ui.title()
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.R,
		config = { align = 'cm', padding = 0.1 },
		nodes = {{
			n = G.UIT.T,
			config = { text = 'Reduce update calls to some objects', colour = G.C.WHITE, scale = 0.4 }
		}}
	}
end

function ui.rows()
	--- @type balatro.UIElement.Definition[]
	return {
		ui.title(),
		ui.generic('card'),
		ui.generic('dynatext', { age = true }),
		ui.generic('uie'),
		ui.controller()
	}
end

function ui.main()
	return uiutil.root(ui.rows())
end

return ui