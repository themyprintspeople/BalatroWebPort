local uiutil = require("futil.cui.util")

--- @class futil.cui.tweaks
local ui = {
	opts = {
		ev2 = {
			freqs = { 60, 120, 240, 480, 960, 1920, 3840 },
			freqs_text = { 60, 120, 240, 480, '1k', '2k', '4k' },
			accel = { 1, 2, 4, 8, 16, 32, 4, 128 },
			width = 2,
		},
		gc2 = {
			step_base = { 1, 2, 4, 8, 16 },
			step_accel = { 1, 2, 4, 8, 12 },
			accel_thres = { 50, 100, 150, 200, 300 },
			width = 2,
		}
	},
}

function ui.ev2()
	local conf = G.SETTINGS.futil
	--- @type balatro.UIElement.Definition[]
	return {
		uiutil.toggle({
			label = 'Event V2',
			ref_table = conf.ev2,
			ref_value = 'enable',
			callback = function (val)
				local ev2m = require("futil.ev2.migrator")
				if val then ev2m:tov2() else ev2m:tovanilla() end
			end,
			tooltip = { text = {
				'Event V2 is a replacement for Balatro\'s Event Manager,',
				'reducing update time on high queues, and allows',
				'animations to run much faster.',
				'Handy\'s event acceleration will not have any effect.',
			} }
		}),
		uiutil.splitter(),

		uiutil.cycle({
			label = 'Frequency',
			options = ui.opts.ev2.freqs_text,
			values = ui.opts.ev2.freqs,
			ref_table = conf.ev2,
			ref_value = 'frequency',
			tooltip = { text = {
				'Maximum times EventManager should run in a single second.',
				'Higher values may not have effect unless acceleration is increased.'
			} },
			onCycle = function (cycle)
				require("futil.ev2.migrator").ev2.queue_dt = 1 / ui.opts.ev2.freqs[cycle.to_key]
			end,
			w = ui.opts.ev2.width,
		}),
		uiutil.cycle({
			label = 'Acceleration',
			options = ui.opts.ev2.accel,
			ref_table = conf.ev2,
			ref_value = 'acceleration',
			tooltip = { text = {
				'Maximum times EventManager should run in a single frame.',
				'Higher values may decrease performance.'
			} },
			onCycle = function (cycle)
				require("futil.ev2.migrator").ev2.max_burst = cycle.to_val
			end,
			w = ui.opts.ev2.width,
		}),
	}
end

function ui.gc2()
	local conf = G.SETTINGS.futil
	--- @type balatro.UIElement.Definition[]
	return {
		uiutil.toggle({
			label = 'Custom GC',
			ref_table = conf.customgc,
			ref_value = 'enable',
			tooltip = { text = {
				'A customized garbage collector replacing Balatro\'s GC implementation.',
			} }
		}),
		uiutil.splitter(),

		uiutil.cycle({
			label = 'Base Step',
			options = ui.opts.gc2.step_base,
			ref_table = conf.customgc,
			ref_value = 'baseStep',
			tooltip = {
				text = {
					'Base GC step for every frame.'
				}
			},
			w = ui.opts.gc2.width,
		}),

		uiutil.cycle({
			label = 'Accel (MB)',
			options = ui.opts.gc2.accel_thres,
			ref_table = conf.customgc,
			ref_value = 'boostMin',
			tooltip = {
				text = {
					'Minimum memory to accelerate GC.'
				}
			},
			w = ui.opts.gc2.width,
		}),

		uiutil.cycle({
			label = 'Accel Step',
			options = ui.opts.gc2.step_accel,
			ref_table = conf.customgc,
			ref_value = 'boostMult',
			tooltip = {
				text = {
					'Extra GC step for every MB above acceleration threshold.'
				}
			},
			w = ui.opts.gc2.width,
		}),
	}
end

--- @type futil.cui.util.Gen[]
ui.array = {
	ui.ev2,
	ui.gc2,
}

function ui.main()
	return uiutil.rootCols(ui.array)
end

return ui