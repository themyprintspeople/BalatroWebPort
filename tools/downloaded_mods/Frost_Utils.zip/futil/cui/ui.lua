local sReduce = require("futil.cui.reduce")
local sMain = require("futil.cui.main")
local sTweaks = require("futil.cui.tweaks")
local sLoad = require("futil.cui.loading")

--- @class balatro.Functions.Uidef
local uidef = G.UIDEF

function uidef.futil_extra_tabs()
	--- @type balatro.UI.Tab.Tab[]
	return {{
		label = "Tweaks",
		tab_definition_function = function () return sTweaks.main() end,
	}, {
		label = "Reductions",
		tab_definition_function = function () return sReduce.main() end,
	}, {
		label = "Loading",
		tab_definition_function = function () return sLoad.main() end,
	}}
end

if not SMODS then
	local _options = create_UIBox_options
	function create_UIBox_options()
		local contents = _options()
		local m = UIBox_button({
			minw = 5,
			button = "futil_menu",
			label = { "Frost's Utils" },
			colour = G.C.BLUE
		})
		table.insert(contents.nodes[1].nodes[1].nodes[1].nodes, m)
		return contents
	end

	function G.FUNCS.futil_menu()
		local tabs = {
			{
				label = "Config",
				chosen = true,
				tab_definition_function = G.UIDEF.futil_config
			}
		}
		for i,v in ipairs(uidef.futil_extra_tabs()) do
			table.insert(tabs, v)
		end

		G.FUNCS.overlay_menu {
			definition = create_UIBox_generic_options({
				back_func = "options",
				contents = {
					create_tabs({
						snap_to_nav = true,
						tabs = tabs
					})
				}
			})
		}
	end
end

function uidef.futil_config() return sMain.main() end
