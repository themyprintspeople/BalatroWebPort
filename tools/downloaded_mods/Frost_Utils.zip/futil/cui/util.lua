--- @class futil.cui.util
local util = {}

--- @alias futil.cui.util.Gen fun(): balatro.UIElement.Definition[]

util.funcs = {
	cycleSet = 'futil_cycle_set'
}

--- @param w? number
function util.splitter(w)
	--- @type balatro.UIElement.Definition[]
	return {
		n = G.UIT.R,
		config = { padding = 0.1, align = 'cm' },
		nodes = {{ n = G.UIT.R, config = { colour = G.C.GREY, minw = w or 2.75, minh = 0.08, r = true } }}
	}
end

--- @class futil.cui.util.CycleParam: balatro.UI.OptionCycleParam
--- @field onCycle? fun(cycle: balatro.UI.CycleCallbackParam)
--- @field values? any[]

--- @param opts futil.cui.util.CycleParam
function util.cycle(opts)
	if not opts.opt_callback then
		opts.opt_callback = util.funcs.cycleSet
	end
	if not opts.scale then
		opts.scale = 0.8
	end
	if not opts.current_option and (opts.values or opts.options) and opts.ref_table and opts.ref_value ~= nil then
		opts.current_option = get_index(opts.values or opts.options, opts.ref_table[opts.ref_value]) or 1 --- @diagnostic disable-line
	end
	return create_option_cycle(opts)
end

--- @param opts balatro.UI.ToggleParam
function util.toggle(opts)
	opts.w = opts.w or 2

	return create_toggle(opts)
end

--- @param cycle balatro.UI.CycleCallbackParam
function util.cycleSet(cycle)
	if cycle.cycle_config.onCycle then cycle.cycle_config.onCycle(cycle) end

	local rt = cycle.cycle_config.ref_table
	local rv = cycle.cycle_config.ref_value
	if not (rt and rv) then return end

	local vals = cycle.cycle_config.values
	rt[rv] = vals and vals[cycle.to_key] or cycle.to_val
end

--- @param list futil.cui.util.Gen[]
--- @param row? boolean
--- @param center? boolean
function util.colGen(list, row, center)
	--- @type balatro.UIElement.Definition[]
	local nodes = {}
	for i,v in ipairs(list) do
		nodes[i] = { n = row and G.UIT.R or G.UIT.C, config = {padding = 0.1, align = center and 'cm' or nil}, nodes = v() }
	end
	return nodes
end

--- @param ui balatro.UIElement.Definition[]
function util.root(ui)
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.ROOT,
		config = { colour = G.C.CLEAR },
		nodes = ui
	}
end

--- @param list futil.cui.util.Gen[]
--- @param row? boolean
function util.rootCols(list, row)
	return util.root(util.colGen(list, row))
end

--- @param title string
--- @param tooltip? string[]
function util.gtitle(title, tooltip)
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.R,
		config = { padding = 0.215, align = 'cm', tooltip = tooltip and { text = tooltip } or nil },
		nodes = {{
			n = G.UIT.T,
			config = { text = title, scale = 0.4, }
		}}
	}
end

G.FUNCS[util.funcs.cycleSet] = function(...) return util.cycleSet(...) end

return util