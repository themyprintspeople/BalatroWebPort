local futil = require("futil.lib.std")
local EVMQueue = require('futil.ev2.queue')

--- @class b.EventManager: Object
--- @field queues table<balatro.EventManager.QueueType, b.Evm.Queue>
local IEVM = Object:extend()
IEVM.prevTotal = 0
IEVM.queue_dt = 1 / G.SETTINGS.futil.ev2.frequency
IEVM.max_burst = G.SETTINGS.futil.ev2.acceleration
IEVM.interp_timers = true
IEVM.lastTime = 0
IEVM.lastTotalTime = 0

function IEVM:init()
	self.queues = {
		unlock = EVMQueue(),
		base = EVMQueue(),
		tutorial = EVMQueue(),
		achievement = EVMQueue(),
		other = EVMQueue(),
	}
end

--- @param event balatro.EventManager.QueueType
function IEVM:get_queues(event)
	local q = self.queues[event]
	if not q or not q.unblockable then
		local nq = EVMQueue()
		if q then for i, v in ipairs(q) do nq:add(v) end end
		q = nq
		self.queues[event] = nq
	end
	return q
end

--- @param event balatro.Event
--- @param queue? balatro.EventManager.QueueType
--- @param front? boolean
function IEVM:add_event(event, queue, front)
	self:get_queues(queue or 'base'):add(event, front)
end

function IEVM:clear_queue(queue, exception)
	if not queue then
		for k, entry in pairs(self.queues) do
			self:get_queues(k):clear()
		end
		return
	end

	if exception then
		for k, entry in pairs(self.queues) do
			if k ~= exception then
				self:get_queues(k):clear()
			end
		end
		return
	end

	self:get_queues(queue):clear()
end

--- @protected
function IEVM:cycle_update()
	for k, queue in pairs(self.queues) do
		local q = self:get_queues(k)
		if G.SETTINGS.paused then
			q:cyclePaused()
		else
			q:cycle()
		end
	end
end

function IEVM:getFreqAccel()
	if not futil.allowSpeedup() then
		return 1, 1 / 60
	end
	if G.SETTINGS.paused then
		return 1, 1 / 50
	end
	if G.STAGE == G.STAGES.MAIN_MENU then
		return 1, 1 / 60
	end
	if Talisman and Talisman.scoring_coroutine or G.SCORING_COROUTINE then
		return 1, 1 / 10
	end
	return self.max_burst, self.queue_dt
end

function IEVM:update(dt_real, forced)
	local max_burst, interval = self:getFreqAccel()
	local dt_total = G.TIMERS.TOTAL - self.lastTotalTime
	local buffered_dt = G.TIMERS.REAL - self.lastTime
	local count = math.floor(buffered_dt / interval)
	local count_lim = math.min(max_burst, count)

	if count_lim > 0 and self.interp_timers then
		G.TIMERS.REAL = G.TIMERS.REAL - dt_real
		G.TIMERS.TOTAL = G.TIMERS.TOTAL - dt_total
	end

	for i = 1, count_lim, 1 do
		if self.interp_timers then
			G.TIMERS.REAL = G.TIMERS.REAL + dt_real / count_lim
			G.TIMERS.TOTAL = G.TIMERS.TOTAL + dt_total / count_lim
		end
		self:cycle_update()
	end

	self.lastTime = self.lastTime + count * interval
	self.lastTotalTime = G.TIMERS.TOTAL
end

--- @type b.EventManager | fun(): b.EventManager
local EVM = IEVM

return EVM
