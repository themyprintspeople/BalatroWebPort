local LinkedList = require('futil.ev2.linkedlist')

--- @alias b.Evm.QueueLinkNode f.LinkedListNode<balatro.Event, b.Evm.QueueLinkNode>
--- @alias b.Evm.QueueLink f.LinkedList<balatro.Event, b.Evm.QueueLinkNode>

--- @class b.Evm.Queue: Object
--- @field all b.Evm.QueueLink
--- @field unblockable b.Evm.QueueLink
--- @field unblockableLinks table<b.Evm.QueueLinkNode, b.Evm.QueueLinkNode>
--- @field paused b.Evm.QueueLink
--- @field pausedLinks table<b.Evm.QueueLinkNode, b.Evm.QueueLinkNode>
local IEVMQueue = Object:extend()
IEVMQueue.count = 0
IEVMQueue.countUnblockable = 0
IEVMQueue.countPaused = 0

--- @protected
function IEVMQueue:init()
	self.all = LinkedList()
	self.unblockable = LinkedList()
	self.unblockableLinks = {}
	self.paused = LinkedList()
	self.pausedLinks = {}
end

--- @protected
--- @param event balatro.Event
--- @param list b.Evm.QueueLink
--- @param front? boolean
--- @param node? b.Evm.QueueLinkNode
function IEVMQueue:addNode(event, list, front, node)
	if node then
		local n = front and node:prepend(event) or node:append(event)
		list:sync()
		return n
	end
	return front and list:unshift(event) or list:push(event)
end

--- @param event balatro.Event
--- @param front? boolean
--- @param onNode? b.Evm.QueueLinkNode
function IEVMQueue:add(event, front, onNode)
	self.count = self.count + 1
	local node = self:addNode(event, self.all, front, onNode)

	event.complete = nil
	event.removed = nil
	if event.use_lln then event.lln = node end

	if not event.blockable then
		self.countUnblockable = self.countUnblockable + 1
		local node3 = self:addNode(event, self.unblockable, front, onNode)
		self.unblockableLinks[node] = node3
		self.unblockableLinks[node3] = node
		if event.use_lln then event.lln_unblockable = node3 end
	end

	if event.created_on_pause then
		self.countPaused = self.countPaused + 1
		local node2 = self:addNode(event, self.paused, front, onNode)
		self.pausedLinks[node] = node2
		self.pausedLinks[node2] = node
		if event.use_lln then event.lln_paused = node2 end
	end

	return node
end

--- @param node b.Evm.QueueLinkNode
function IEVMQueue:remove(node)
	if node.value.removed then return end
	node.value.removed = true
	self.count = self.count - 1
	self.all:detachNode(node)

	local unblockable = self.unblockableLinks[node]
	if unblockable then
		self.countUnblockable = self.countUnblockable - 1
		self.unblockable:detachNode(unblockable)
		self.unblockableLinks[node] = nil
		self.unblockableLinks[unblockable] = nil
	end

	local paused = self.pausedLinks[node]
	if paused then
		self.countPaused = self.countPaused - 1
		self.paused:detachNode(paused)
		self.pausedLinks[node] = nil
		self.pausedLinks[paused] = nil
	end
end

--- @type balatro.Event.Result
local result_swap = {
	blocking = false,
	completed = false,
	pause_skip = false,
	time_done = false
}

--- @param node b.Evm.QueueLinkNode
--- @param node2? b.Evm.QueueLinkNode
function IEVMQueue:handle(node, node2)
	local ev = node.value
	--if G.SETTINGS.paused and ev.timer == 'TOTAL' then return end

	result_swap.blocking = false
	result_swap.completed = false
	result_swap.time_done = false
	result_swap.pause_skip = false

	ev:handle(result_swap)

	if not result_swap.pause_skip and result_swap.completed and result_swap.time_done then
		self:remove(node2 or node)
	end
end

function IEVMQueue:clear()
	self.all:each(function (e, node)
		if not e.no_delete then
			self:remove(node)
		end
	end)
end

function IEVMQueue:cycle()
	local unblocked_node = self.unblockable.first

	local node = self.all.first
	while node do
		self:handle(node)
		if unblocked_node and unblocked_node.value == node.value then
			unblocked_node = unblocked_node.next
		end
		node = node.next
		if not result_swap.pause_skip and result_swap.blocking then break end
	end

	while unblocked_node do
		self:handle(unblocked_node, self.unblockableLinks[unblocked_node])
		unblocked_node = unblocked_node.next
	end
end

function IEVMQueue:cyclePaused()
	local node = self.paused.first
	local unpaused = false
	local blocked = false

	while node do
		local nnode = not unpaused and self.pausedLinks[node] or nil
		if not blocked or not node.value.blockable then
			self:handle(node, nnode)
		end
		if not G.SETTINGS.paused and not unpaused then
			unpaused, node = true, nnode
		end
		blocked = blocked or not result_swap.pause_skip and result_swap.blocking
		node = node.next
	end
end

function IEVMQueue:clearAll()
    self.all:clear()
    self.unblockable:clear()
    self.unblockableLinks = {}
    self.paused:clear()
    self.pausedLinks = {}
    self.count = 0
end

--- @type b.Evm.Queue | fun(): b.Evm.Queue
local EVMQueue = IEVMQueue

return EVMQueue