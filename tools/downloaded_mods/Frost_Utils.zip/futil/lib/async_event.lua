--- @class b.AsyncEvent: Object
--- @field protected _resumeEventCount number
--- @field protected _ln? b.Evm.QueueLinkNode
--- @field protected _eventQueue? balatro.Event
--- @field protected _eventSafeguard? balatro.Event
--- @field private _ehook function
--- @field private _ehookid number
---
--- @field co? thread
local IAsyncEvent = Object:extend()

local DEBUG = false

IAsyncEvent.minEventToYield = 100
IAsyncEvent.swapped = 0
IAsyncEvent.time = 0
IAsyncEvent._resumeEventCount = 0
--- @private
IAsyncEvent._efunc = G.E_MANAGER.queues.base.add

--- @protected
function IAsyncEvent:init() end

function IAsyncEvent:onInit() end
function IAsyncEvent:onCycle() end
function IAsyncEvent:onYield() end
function IAsyncEvent:onAbort() end
function IAsyncEvent:onFinalize() end

--- @protected
function IAsyncEvent:initHookEv()
	self._ehookid = math.random()
	local id = self._ehookid

	self._efunc = G.E_MANAGER.queues.base.add
	self._ehook = function (reg, event, front, node)
		if not self._ln or front or node or self._ehookid ~= id then
			return self._efunc(reg, event, front, node)
		end
		self.swapped = self.swapped + 1
		self._ln = self._efunc(reg, event, front, self._ln)
		return self._ln
	end
	G.E_MANAGER.queues.base.add = self._ehook
end

--- @protected
function IAsyncEvent:unhookEv()
	local b = G.E_MANAGER.queues.base
	if b.add == self._ehook then b.add = self._efunc
	else print('unhook G.E_MANAGER.queues.base.add failed')
	end
	self._ehookid = nil
end

--- @protected
function IAsyncEvent:initCycleEvent()
	return Event({ func = function () return self:cycle(self.co) end, lln = true })
end

--- @protected
function IAsyncEvent:initGuardingEvent()
	return Event({ func = function () return self:safeguard(self.co) end, lln = true, blockable = false, blocking = false, no_delete = true })
end

--- @protected
function IAsyncEvent:initAnalysisEvent()
	local e
	e = Event({
		func = function ()
			--- @type b.Evm.QueueLinkNode
			local i = e.lln.next
			while i do
				if not i.value.blockable then
					print('Unblockable event is added:', i.value.func)
				end
				i = i.next
			end
			return true
		end,

		blocking = false,
		blockable = false,
		lln = true
	})
	return e
end

--- @param co? thread
function IAsyncEvent:isactive(co)
	return co and co == self.co and coroutine.status(self.co) ~= "dead"
end

--- @protected
--- @return boolean
function IAsyncEvent:cycle(co)
	if not self:isactive(co) then return true end
	if G.SETTINGS.paused then return false end


	self._resumeEventCount = G.E_MANAGER.queues.base.count
	self._ln = self._eventQueue.lln
	self:onCycle()
	local t = love.timer.getTime()
	assert(coroutine.resume(self.co))
	self.time = self.time + love.timer.getTime() - t

	if not self:isactive(self.co) then
		self:finalize()
		return true
	end

	self._eventQueue = self:initCycleEvent()
	G.E_MANAGER.queues.base:add(self._eventQueue, nil, self._ln)

	self:onYield()

	self._ln = nil
	return true
end

--- @protected
--- @return boolean
function IAsyncEvent:safeguard(co)
	if not self:isactive(co) then return true end
	if not self._eventQueue.removed then return false end -- must be removed
	if not self._eventQueue.complete then
		print('AsyncEvent exited abnormally')
		self:onAbort()
	end
	self:finalize()
	return true
end

function IAsyncEvent:shouldyield()
	return G.E_MANAGER.queues.base.count > self._resumeEventCount + self.minEventToYield
end

function IAsyncEvent:yield()
	return coroutine.running() == self.co and self:shouldyield() and coroutine.yield()
end

function IAsyncEvent:canRun()
	if self.co then
		return false, "already running"
	end
	local co = coroutine.running()
	if not co then
		return false, "coroutine not available"
	end
	return true
end

function IAsyncEvent:run()
	assert(self:canRun())
	if DEBUG then print('AsyncEvent run') end
	self:onInit()

	self.co = coroutine.running()
	self._eventQueue = self:initCycleEvent()
	self._eventSafeguard = self:initGuardingEvent()
	G.E_MANAGER:add_event(self._eventQueue)
	G.E_MANAGER:add_event(self._eventSafeguard)
	G.E_MANAGER:add_event(self:initAnalysisEvent())
	self:initHookEv()

	coroutine.yield()
end

function IAsyncEvent:runNew()
	return assert(coroutine.resume(coroutine.create(function() return self:run() end)))
end

function IAsyncEvent:finalize()
	if DEBUG then print('AsyncEvent finalize') end
	self:onFinalize()

	self._ln = nil
	self.co = nil
	self._eventQueue = nil
	self._eventSafeguard = nil
	self:unhookEv()
end

--- @type b.AsyncEvent | fun(): b.AsyncEvent
local AsyncEvent = IAsyncEvent
return AsyncEvent