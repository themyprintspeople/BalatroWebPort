local AsyncEvent = require('futil.lib.async_event')
local C2 = Card
local G2 = _G

--- @class b.AsyncScoring: b.AsyncEvent
--- @field protected _cfunc? function
--- @field protected _csfunc? function
--- @field protected _chook? function
--- @field protected _cshook? function
--- @field protected _chookid? number
---
--- @field protected _ctn? number -- TODO split to async_event
--- @field protected _cts? number -- TODO split to async_event
---
--- @field protected _tstr string
--- @field protected _ui? balatro.UIBox
--- @field protected _uic number
---
--- @field protected ev2_t? number
--- @field protected ev2_a? number
local IAsyncScore = AsyncEvent:extend()

IAsyncScore.calcYieldTimeInterval = 100 -- n of calcs before yielding from time
IAsyncScore.calcYieldTimeWindow = 0.016 -- seconds
IAsyncScore.calculations = 0
IAsyncScore.aborted = false
IAsyncScore._tstr = ''
IAsyncScore._uic = 0

function IAsyncScore:hook()
	self._chookid = math.random()
	local id = self._chookid

	self._cfunc = C2.calculate_joker
	self._chook = function (...)
		if id == self._chookid then
			self:yield()
			if self.aborted  then return end
			self.calculations = self.calculations + 1
		end
		return self._cfunc(...)
	end
	C2.calculate_joker = self._chook

	self._csfunc = card_eval_status_text
	self._cshook = function(...)
		if self.aborted then return end
		return self._csfunc(...)
	end
	G2.card_eval_status_text = self._cshook
end

--- @param lock boolean
function IAsyncScore:setMoveLock(lock)
	if G.play then G.play.no_sort = lock end
	if G.hand then G.hand.no_sort = lock end
	if G.jokers then G.jokers.no_sort = lock end
	if G.consumeables then G.consumeables.no_sort = lock end
end

function IAsyncScore:unhook()
	if C2.calculate_joker == self._chook then C2.calculate_joker = self._cfunc
	else print('unhook calculate_joker failed')
	end
	if G2.card_eval_status_text == self._cshook then G2.card_eval_status_text = self._csfunc
	else print('unhook card_eval_status_text failed')
	end
	self._chookid = nil
end

function IAsyncScore:onInit()
	self:hook()
	self:setMoveLock(true)

	G.current_eval = self
	self._ui = UIBox({
		definition = self:createUi(),
		config = { align = 'cr', major = G.ROOM_ATTACH, offset = { x = -3.5, y = 0 } }
	})
end

function IAsyncScore:onCycle()
	local t = love.timer.getTime()
	self._ctn = 0
	self._cts = t + self.calcYieldTimeWindow

	if self._ui then
		if t > self._uic then
			self._uic = t + 0.1
			self._ui:recalculate()
		end
	end
end

function IAsyncScore:onYield()
	self._tstr = string.format("%.2fs", self.time)
end

function IAsyncScore:shouldyield()
	self._ctn = self._ctn + 1
	return self._ctn % self.calcYieldTimeInterval == 0 and love.timer.getTime() > self._cts or AsyncEvent.shouldyield(self)
end

function IAsyncScore:onFinalize()
	self:unhook()
	self:setMoveLock(false)

	if self.ev2_t then 	G.E_MANAGER.queue_dt = self.ev2_t end
	if self.ev2_a then 	G.E_MANAGER.max_burst = self.ev2_a end

	G.current_eval = nil
	if self._ui then
		self._ui:remove()
		self._ui = nil
	end
end

function IAsyncScore:createUiCalcs()
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.R,
		config = { align = 'r' },
		nodes = {{
			n = G.UIT.T,
			config = {
				ref_table = self,
				ref_value = 'calculations',
				no_recalc = true,
				scale = 0.4
			}
		}, {
			n = G.UIT.T,
			config = {
				text = ' calcs',
				scale = 0.4
			}
		}}
	}
end

function IAsyncScore:createUiEvents()
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.R,
		config = { align = 'r' },
		nodes = {{
			n = G.UIT.T,
			config = {
				ref_table = self,
				ref_value = 'swapped',
				no_recalc = true,
				scale = 0.4
			}
		}, {
			n = G.UIT.T,
			config = {
				text = ' events',
				scale = 0.4
			}
		}}
	}
end

function IAsyncScore:createUiTime()
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.R,
		config = { align = 'r' },
		nodes = {{
			n = G.UIT.T,
			config = {
				ref_table = self,
				ref_value = '_tstr',
				no_recalc = true,
				scale = 0.4
			}
		}, {
			n = G.UIT.T,
			config = {
				text = ' time',
				scale = 0.4
			}
		}}
	}
end
--[[
function IAsyncScore:createUIContainer(nodes, align)
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.C,
		config = { minw = 2.5, align = align },
		nodes = nodes
	}
end
]]

function IAsyncScore:createUiStats()
	--- @type balatro.UIElement.Definition[]
	return {
		self:createUiCalcs(),
		self:createUiEvents(),
		self:createUiTime(),
	}
end

function IAsyncScore:createUiAbort()
	local u = UIBox_button{
		label = {'Abort'},
		button = 'futil_ascore_abort',
		ref_table = self,
	}
	u.config.padding = 0.2
	return u
end

function IAsyncScore:createUiRows()
	--- @type balatro.UIElement.Definition[]
	return {
		{ n = G.UIT.R, config = { align = 'r' }, nodes = {{ n = G.UIT.C, nodes = self:createUiStats() }} },
		self:createUiAbort(),
	}
end

function IAsyncScore:createUi()
	--- @type balatro.UIElement.Definition
	return {
		n = G.UIT.ROOT,
		config = { colour = G.C.CLEAR, padding = 0.2 },
		nodes = self:createUiRows()
	}
end

--- @type b.AsyncScoreStatic | b.AsyncScoring | fun(): b.AsyncScoring
local AsyncScore = IAsyncScore
--- @class b.AsyncScoreStatic
local AsyncScoreStatic = AsyncScore

function AsyncScoreStatic.createAndRun()
	local as = AsyncScore()
	as:run()
	return as
end

function G.FUNCS.futil_ascore_abort(e)
	if e.config.ref_table.aborted then return end
	e.config.ref_table.aborted = true

	e.config.ref_table.ev2_t = G.E_MANAGER.queue_dt
	e.config.ref_table.ev2_a = G.E_MANAGER.max_burst
	G.E_MANAGER.queue_dt = 1 / 3840
	G.E_MANAGER.max_burst = 32
end

return AsyncScore