local futil = {}

function futil.isMP()
	return MP and MP.LOBBY and MP.LOBBY.code and true or false
end

function futil.allowSpeedup()
	return not futil.isMP()
end

return futil