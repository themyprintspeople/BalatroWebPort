local ffi = require("ffi")

local x = {}

--- @param objType string
--- @param ptrType? string
--- @param blocksize? number
function x.pooler(objType, ptrType, blocksize)
	local m = {
		size = ffi.sizeof(objType),
		t = ffi.typeof(objType),
		ptr_t = ffi.typeof(ptrType or objType.."*"),
		psize = blocksize or 128,
		poff = -1,
	}
	function m.malloc()
		if m.poff >= m.psize or m.poff == -1 then
			m.poff = 0
			m.pdata = love.data.newByteData(m.size * m.psize)
			m.pptr = m.ptr_t(m.pdata:getFFIPointer())
		end
		local off = m.poff
		m.poff = m.poff + 1
		return m.pptr[off], off, m.pdata
	end
	print(string.format("futil/pm: %s: %d bytes x %d pool -> %d bytes", objType, m.size, m.psize, m.size * m.psize))
	return m
end

return x