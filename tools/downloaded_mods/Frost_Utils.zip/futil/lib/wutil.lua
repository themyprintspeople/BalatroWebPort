
local x = {}

--- @param file string
--- @param replaces [string, string][]
function x.patchAndLoad(file, replaces)
	local code = assert(love.filesystem.read(file))

	for i,v in ipairs(replaces) do
		local count
		local pat = v[3] and v[1] or v[1]:gsub("[%(%)%.%%%+%-%*%?%[%]%^%$]", function(m) return '%'..m end)
		code, count = code:gsub(pat, v[2])
		if count <= 0 then error(string.format("pattern '%s' resulted in no match", pat)) end
	end
	return assert(loadstring(code, string.format('@futil/virt/worker/%s', file)))()
end

return x