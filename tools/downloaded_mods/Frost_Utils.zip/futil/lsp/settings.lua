--- @meta

--- @alias futil.Settings.JitMode
--- | 1 Don't do anything
--- | 2 On
--- | 3 Off

--- @class futil.Settings.GC
--- @field enable boolean
--- Milliseconds
--- @field interval number
--- Minimum MB to increase step
--- @field boostMin number
--- Step multiplier per MB
--- @field boostMult number
--- Base GC step per frame
--- @field baseStep number

--- @class futil.Settings.EV2
--- @field enable boolean
--- @field frequency number
--- @field acceleration number

--- @class futil.Settings.AS
--- evaluate play
--- @field gfep boolean
--- end of round
--- @field er boolean
--- Refers errorhandler thread to the scoring coroutine instead of main thread
--- @field debugtrace boolean

--- @class futil.Settings.Reduction
--- @field enable boolean
--- @field rate number

--- @class futil.Settings.Reduction.Moveable: futil.Settings.Reduction
--- @field minAge? number

--- @class futil.Settings.Reduction.Controller
--- @field enable boolean
--- @field idleFreq number
--- @field activeFreq number

--- @class futil.Settings.Reductions
--- @field controller futil.Settings.Reduction.Controller
--- @field uie futil.Settings.Reduction.Moveable
--- @field card futil.Settings.Reduction.Moveable
--- @field dynatext futil.Settings.Reduction.Moveable

--- @class futil.Settings
--- - 0 - none
--- - 1 - partial
--- - 2 - all
--- @field shaderReduction number
--- @field customgc futil.Settings.GC
--- @field ev2 futil.Settings.EV2
--- @field asyncScoring futil.Settings.AS
--- @field jit futil.Settings.JitMode
--- @field reductions futil.Settings.Reductions

--- @class balatro.Settings
--- @field futil futil.Settings

--- @class balatro.UI.ToggleParam
--- @field tooltip? balatro.UI.TooltipParam

--- @class balatro.UI.OptionCycleParam
--- @field tooltip? balatro.UI.TooltipParam