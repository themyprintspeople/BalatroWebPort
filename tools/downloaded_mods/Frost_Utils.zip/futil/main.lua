require("futil.minimount")("Frost's Utils", "futil", _mod_dir_frostutil, "futil", "futil")
local preload = require("futil.config.preload")

require("futil.optimization.defer")
require("futil.overrides")
require("futil.cui.ui")
if preload.config.parallel_move then
	require("futil.parallel_move.host.moveable")
	if preload.config.parallel_align then
		require("futil.parallel_move.host.cardarea")
	end
	if preload.config.parallel_controller then
		require("futil.parallel_move.host.controller")
	end
end

G.ARGS.speed_options = { 0.5, 1, 2, 4, 8, 16, 32, 64, 128, 512, 2048, 8192, 32768 }
G.ARGS.speed_options_vanilla = { 0.5, 1, 2, 4 }

G.ARGS.futil_blankimage = love.graphics.newImage(love.image.newImageData(8, 8))
G.ARGS.futil_blankquad = love.graphics.newQuad(0, 0, 8, 8, G.ARGS.futil_blankimage)
G.ARGS.futil_blank = {
	image = G.ARGS.futil_blankimage,
	name = 'futil_blank',
	px = 32,
	py = 32,
}

local function futil_logtime(x)
	local t = love.timer.getTime()
	print(string.format('futil: loaded %s in %.1fms (CPU: %.1f%%)', x, t * 1000, os.clock() / t * 100))
end

local startup = Game.start_up
function Game:start_up()
	startup(self)
	require("futil.postload")
	futil_logtime('startup')
end
futil_logtime('futil')
