--- @diagnostic disable: duplicate-set-field, inject-field

local DEBUG = false

local set_render_settings = Game.set_render_settings
function Game:set_render_settings()
	set_render_settings(self)

	for i, v in pairs(self.animation_atli) do
        self:defer_atlas(self.ANIMATION_ATLAS[v.name], v.path)
    end

    for i, v in pairs(self.asset_atli) do
        local atlas = self.ASSET_ATLAS[v.name]
        self:defer_atlas(atlas, v.path)
    end

    for i, v in pairs(self.asset_images) do
        self:defer_atlas(self.ASSET_ATLAS[v.name], v.path)
    end
end

local start_up = Game.start_up
function Game:start_up()
    love.window.setVSync(0)

    local set_mode = self.FUNCS.apply_window_changes
    function self.FUNCS.apply_window_changes()
        local vsync = self.SETTINGS.WINDOW.vsync
        self.SETTINGS.WINDOW.vsync = 0
        set_mode()
        self.SETTINGS.WINDOW.vsync = vsync
    end

    start_up(self)

    self.FUNCS.apply_window_changes = set_mode

    love.window.setVSync(self.SETTINGS.WINDOW.vsync or 1)
end

function Game:defer_shaders()
    self.LOADED_SHADERS = {}
    self.CUSTOM_SHADERS = {}
    setmetatable(self.SHADERS, {
        __index = function (t, k)
            local shader = self.LOADED_SHADERS[k]
            if shader ~= nil then return shader or nil end
            shader = self:load_defer_shader(k)
            self.LOADED_SHADERS[k] = shader or false
            t[k] = shader
            return shader
        end
    })
end

function Game:load_defer_shader(k)
    if DEBUG then print('futil: loading deferred shader', k) end

    if self.CUSTOM_SHADERS[k] then
        return self:load_defer_shader_custom(self.CUSTOM_SHADERS[k])
    end
    return self:load_defer_shader_vanilla(k)
end

function Game:load_defer_shader_custom(path)
    local content = assert(NFS.newFileData(path))
    local ok, shader = pcall(love.graphics.newShader, content)
    if not ok then
        assert(love.filesystem.write('__tmp_shader', content))
        shader = love.graphics.newShader('__tmp_shader')
        assert(love.filesystem.remove('__tmp_shader'))
    end
    return shader
end

function Game:load_defer_shader_vanilla(prop)
    local path = 'resources/shaders/' .. prop .. '.fs'
    if love.filesystem.getInfo(path) then
        return love.graphics.newShader(path)
    end
end

--- @class futil.defer.atlasOpts
--- @field nfs? boolean
--- @field dpi? number
--- @field nomipmap? boolean
--- @field imagedata? love.ImageData

--- @param atlas any
--- @param path string
--- @param opts? futil.defer.atlasOpts
function Game:load_defer_atlas(atlas, path, opts)
    if DEBUG then print('futil: loading deferred atlas', atlas.name) end

    opts = opts or {}
    local file = opts.imagedata or opts.nfs and assert(NFS.newFileData(path)) or path
    atlas.image = love.graphics.newImage(file, {
        mipmaps = true,
        dpiscale = opts.dpi or self.SETTINGS.GRAPHICS.texture_scaling
    })

	if SMODS then
		local mipmap_level = SMODS.config.graphics_mipmap_level_options[SMODS.config.graphics_mipmap_level]
		if not opts.nomipmap and mipmap_level and mipmap_level ~= 0 then
			atlas.image:setMipmapFilter('linear', mipmap_level)
		end
	end

    return atlas.image
end

--- @class futil.defer.fontOpts
--- @field nfs? boolean
--- @field path? string

--- @param font any
--- @param opts? futil.defer.fontOpts
function Game:load_defer_font(font, opts)
    opts = opts or {}
    local path = opts.path or font.file
    if DEBUG then print('futil: loading deferred font', font.key or path) end

    local file = opts.nfs and assert(NFS.newFileData(path)) or path
    font.FONT = love.graphics.newFont(file, font.render_scale or self.TILESIZE)
    return font.FONT
end

--- @param atlas table
--- @param path string
--- @param opts? futil.defer.atlasOpts
function Game:defer_atlas(atlas, path, opts)
    local rawmt = getmetatable(atlas)
    setmetatable(atlas, {
        __index = function(t, k)
            if k ~= "image" then return rawget(t, k) end
            setmetatable(atlas, rawmt)
            return self:load_defer_atlas(atlas, path, opts)
        end
    })
end

--- @param font table
--- @param opts? futil.defer.fontOpts
function Game:defer_font(font, opts)
    setmetatable(font, {
        __index = function(t, k)
            if k ~= "FONT" then return rawget(t, k) end
            setmetatable(t, nil)
            return self:load_defer_font(font, opts)
        end
    })
end
