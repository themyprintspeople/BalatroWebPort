local _loadAPIs = loadAPIs
function loadAPIs()
	_loadAPIs()
	SMODS.futil_loaded = true

	local fontInject = SMODS.Font.inject
	function SMODS.Font.inject(self)
		fontInject(self)
		local mt = getmetatable(self)
		local w = setmetatable({}, mt)
		setmetatable(self, {
			__index = function (t, k)
				if k == "FONT" then
					return G:load_defer_font(self, {
						nfs = true,
						path = self.full_path
					})
				end
				return w[k]
			end
		})
	end

	local atlasInject = SMODS.Atlas.inject
	function SMODS.Atlas.inject(self)
		atlasInject(self)
		local mt = getmetatable(self)
		local w = setmetatable({}, mt)
		setmetatable(self, {
			__index = function (t, k)
				if k == "image_data" then
					w[k] = love.image.newImageData(assert(NFS.newFileData(self.full_path)))
				end
				if k == "image" then
					return G:load_defer_atlas(self, self.full_path, {
						dpi = self.dpi,
						nfs = true,
						nomipmap = self.disable_mipmap,
						imagedata = self.image_data
					})
				end
				return w[k]
			end
		})
	end

	local shaderInject = SMODS.Shader.inject
	function SMODS.Shader.inject(self)
		self.full_path = (self.mod and self.mod.path or SMODS.path) .. 'assets/shaders/' .. self.path
		G.CUSTOM_SHADERS[self.key] = self.full_path
	end
end
