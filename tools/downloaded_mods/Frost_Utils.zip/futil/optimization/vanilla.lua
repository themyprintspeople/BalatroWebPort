--- @diagnostic disable: duplicate-set-field

-- DynaText: reuse already allocated letters

local gtextcache = setmetatable({}, { __mode = 'k' })
DynaText.gtextcache = gtextcache

function DynaText._global_get_text_cache(font, letter)
    if not gtextcache[font] then gtextcache[font] = setmetatable({}, { __mode = 'v' }) end
    local set = gtextcache[font]
    local text = set[letter]
    if not text then
        text = love.graphics.newText(font, letter)
        set[letter] = text
    end
    return text
end

-- GC

local nextGc = 0
local _nuGC = nuGC
function nuGC()
	local s = G.SETTINGS.futil.customgc
	if not s.enable then return _nuGC() end

	collectgarbage("step", s.baseStep or 2)

	local t = love.timer.getTime()
	if t >= nextGc then
		nextGc = t + s.interval / 1000
		local mem = collectgarbage("count")
		local boost = (mem / 1024 - s.boostMin) * s.boostMult
		collectgarbage("step", 1 + math.max(boost, 0))
	end

	collectgarbage("stop")
end

-- UI Fix

local m_init = Moveable.init
function Moveable:init(...)
	--if self.ID then print('skip', self.ID) return end
	return m_init(self, ...)
end

local u_init = UIElement.init
function UIElement:init(...)
	Moveable.init(self)
	return u_init(self, ...)
end

-- Controller

--- @class balatro.Controller
--- @field _nct number
--- @field _pci? boolean
--- @field _pcx? number
--- @field _pcy? number
local Controller = Controller
Controller._nct = 0

local c_gcl = Controller.get_cursor_collision
function Controller:get_cursor_collision(t)
	local s = G.SETTINGS.futil.reductions.controller
	if not s.enable then return c_gcl(self, t) end

	local inactive = self._pcx == t.x and self._pcy == t.y
	local interval = inactive and s.idleFreq or s.activeFreq

	if inactive == self._pci and  G.TIMERS.REAL < self._nct and G.TIMERS.REAL > self._nct - 1/interval * 1.1 then
		return
	end

	for k,v in ipairs(self.collision_list) do
		v.states.collide.is = false
	end

	self._pcx = t.x
	self._pcy = t.y
	self._pci = inactive
	self._nct = G.TIMERS.REAL + 1/interval
	c_gcl(self, t)
end

-- Shader

local shader_decr = {
	--dissolve = true -- dissolve has special rule
}
local shader_send = Sprite.draw_shader
function Sprite:draw_shader(shader, _shadow_height, _send, _no_tilt, other_obj, ms, mr, mx, my, custom_shader, tilt_shadow)
	shader = shader or 'dissolve'
	local red = G.SETTINGS.futil.shaderReduction
	local dm = self.role.draw_major or self
	if not (
		red == 2
		or red == 1 and (
			shader == 'dissolve' and (not dm.dissolve or dm.dissolve <= 0)
			or shader_decr[shader]
		)
	) then
		return shader_send(self, shader, _shadow_height, _send, _no_tilt, other_obj, ms, mr, mx, my, custom_shader, tilt_shadow)
	end

	local replace = self.atlas.name == 'ui_1' and self.sprite_pos.x == 2 and self.sprite_pos.y == 0
	local swa, swb
	if replace then
		swa, swb = self.atlas, self.sprite
		self.atlas, self.sprite = G.ARGS.futil_blank, G.ARGS.futil_blankquad
	end

	if other_obj then
		self:draw_from(other_obj, ms, mr, mx, my)
	else
		self:draw_self()
	end

	if replace then
		self.atlas, self.sprite = swa, swb
	end
end

-- Reduction

--- @param rt any
--- @param conf string
--- @param rv? string
local function genericReduction(rt, rv, conf)
	local obj = {}
	obj.id = 0
	obj.updated = 0
	obj.count = 0
	obj.limit = 0

	rv = rv or 'update'
	local ref = rt[rv]
	rt[rv] = function(o, dt, ...)
		local s = G.SETTINGS.futil.reductions[conf]

		if not s.enable then return ref(o, dt, ...) end

		if s.minAge then
			if not o._r_ct then
				o._r_ct = G.TIMERS.REAL + s.minAge
				return ref(o, dt, ...)
			end
			if o._r_ct > G.TIMERS.REAL then
				return ref(o, dt, ...)
			end
		end

		obj.count = obj.count + 1

		if o._r_id == obj.id or obj.updated >= obj.limit then return end

		o._r_c = o._r_c and o._r_c + 1 or 1
		if o._r_c < s.rate then return end

		o._r_id = obj.id
		o._r_c = 0
		if o._r_s then dt = G.TIMERS.REAL - o._r_s end
		o._r_s = G.TIMERS.REAL

		obj.updated = obj.updated + 1

		return ref(o, dt, ...)
	end

	function obj.cycle()
		if obj.updated < obj.limit then
			obj.id = obj.id + 1
		end
		obj.limit = obj.count / G.SETTINGS.futil.reductions[conf].rate
		obj.updated = 0
		obj.count = 0
	end

	return obj
end

local card = genericReduction(Card, nil, 'card')
local dynatext = genericReduction(DynaText, nil, 'dynatext')
local uie = genericReduction(UIElement, nil, 'uie')

local update = Game.update
function Game:update(dt)
	card.cycle()
	dynatext.cycle()
	uie.cycle()

	return update(self, dt)
end