local futil = require("futil.lib.std")
local E2 = Event

--- @class balatro.CardArea
--- @field no_sort? boolean

--- @class balatro.Event.Config
--- @field lln? boolean

--- @class balatro.Event
--- @field use_lln? boolean
--- @field removed? boolean
--- @field lln? b.Evm.QueueLinkNode
--- @field lln_unblockable? b.Evm.QueueLinkNode
--- @field lln_paused? b.Evm.QueueLinkNode

E2.trigger = 'immediate'
E2.blocking = true
E2.blockable = true
E2.complete = false
E2.start_timer = false
E2.func = function() return true end
E2.delay = 0
E2.timer = 'TOTAL'

--[[ broken with nopeus
local init = E2.init
function E2:init(opts)
	self.use_lln = opts.lln
	return init(self, opts)
end
]]

function CardArea:sort_cards()
	if self.no_sort then return end

	if self.config.type == "joker" or self.config.type == "title_2" then
		table.sort(self.cards, function (a, b) return a.T.x + a.T.w/2 - 100*(a.pinned and a.sort_id or 0) < b.T.x + b.T.w/2 - 100*(b.pinned and b.sort_id or 0) end)
		return
	end

	table.sort(self.cards, function (a, b) return a.T.x + a.T.w/2 < b.T.x + b.T.w/2 end)
end

local _eval_play = G.FUNCS.evaluate_play
local _end_round = end_round

local function wrap_hand(func)
	require("futil.lib.async_scoring").createAndRun()
	if not G.SETTINGS.futil.asyncScoring.debugtrace then return func() end
	return assert(xpcall(func, function(err)
		local f = love.errorhandler(err)
		function love.errorhandler() return f end
		return err
	end))
end

local function wrap_call(func)
	return assert(coroutine.resume(coroutine.create(wrap_hand), func))
end

function G.FUNCS.evaluate_play()
	if not (futil.allowSpeedup() and G.SETTINGS.futil.asyncScoring.gfep) then return _eval_play() end
	return wrap_call(_eval_play)
end

function end_round()
	if not (futil.allowSpeedup() and G.SETTINGS.futil.asyncScoring.er) then return _end_round() end

	local init = Event.init
	function Event:init(...)
		init(self, ...)
		local f = self.func
		self.func = function () return wrap_call(f) end
		Event.init = init
	end
	return _end_round()
end