struct PM_SharedCard_DiscardPos {
	float x;
	float y;
	float r;
};

struct PM_SharedCard {
	struct PM_SharedCard_DiscardPos discard_pos;
	int sort_id; // only during init / load
	int ability_order; // unlikely
	bool pinned; // unliektly
	bool highlighted;
};

struct PM_SharedCardArea {
	int card_limit;
	bool nosort;
};
