struct PM_Vec2_f {
	float x;
	float y;
};

struct PM_Vec2_d {
	double x;
	double y;
};

struct PM_Frame {
	int DRAW;
	int MOVE;
};

struct PM_Transform {
	double x;
	double y;
	double w;
	double h;
	double r;
	double scale;
};

struct PM_GlobalState {
	float time;
	float highlight_h; // unlikely
	struct PM_Transform room_t; // unlikely
	struct PM_Vec2_f cursor;
	int mleak;
	int mcount;
	int frame_update;
	int frame_draw;
	int ca_hand_id; // unlikely, unused
	int ca_play_id; // unlikely, unused
	int ca_discard_id; // unlikely, unused
	int ca_deck_id; // unlikely
	int ca_consumable_id; // unlikely
	int dragging_target;
	uint16_t state; // unlikely
	bool reduced_motion; // unlikely
	bool paused; // unlikely
	bool room_exists; // unlikely
	bool busy;
	bool viewing_deck; // unlikely, unused
	bool coyote_focus; // unlikely
};
