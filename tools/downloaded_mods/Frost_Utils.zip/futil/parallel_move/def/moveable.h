struct PM_Pinch {
	bool x: 1;
	bool y: 1;
};

struct PM_Velocity {
	float x;
	float y;
	float r;
	float scale;
	float mag;
};

struct PM_StateAbility {
	bool can: 1;
	bool is: 1;
};

struct PM_State {
	bool visible;
	struct PM_StateAbility collide;
	struct PM_StateAbility focus;
	struct PM_StateAbility hover;
	struct PM_StateAbility click;
	struct PM_StateAbility drag;
	struct PM_StateAbility release_on;
};

struct PM_Moveable {
	struct PM_Frame FRAME;
	struct PM_Vec2_f shadow_parrallax;
	struct PM_Vec2_f layered_parallax;
	struct PM_Transform T;
	struct PM_Transform VT;
	struct PM_Velocity velocity;
	struct PM_Vec2_d alignment_offset;
	struct PM_Vec2_d role_offset;
	int ID;
	struct PM_State states;
	struct PM_Pinch pinch;
	bool created_on_pause;
	bool refresh_movement;
};

struct PM_Juice {
	float scale;
	float scale_amt;
	float r;
	float r_amt;
	float start_time;
	float end_time;
};
