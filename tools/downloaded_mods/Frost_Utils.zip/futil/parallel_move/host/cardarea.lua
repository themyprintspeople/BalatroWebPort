--- @diagnostic disable: duplicate-set-field

local g = require("futil.parallel_move.host.init")

local ffi = require("ffi")
ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/cardarea.h'))))

local util = require('futil.lib.util')
local cardPool = util.pooler("struct PM_SharedCard", nil, 512)
local areaPool = util.pooler("struct PM_SharedCardArea", nil, 512)

local tcard = {
	init = { command = 'card_init' }
}

local tcardarea = {
	init = { command = 'cardarea_init', config = {} },
	emplace = { command = 'cardarea_addcard' },
	remove = { command = 'cardarea_removecard' },
	sync = { command = 'cardarea_synccard' },
}

local ca_conf = {
	'type', 'deck_height', 'spread'
}

local card_init = Card.init
function Card:init(...)
	card_init(self, ...)
	self.PM_shr, tcard.init.off, tcard.init.data = cardPool.malloc()
	self.PM_shr.sort_id = self.sort_id
	self.discard_pos = self.PM_shr.discard_pos
	tcard.init.id = self.ID
	g.input:push(tcard.init)
end

local area_init = CardArea.init
function CardArea:init(...)
	area_init(self, ...)
	self.cards2 = setmetatable({}, { __mode = 'v' })
	self.PM_shr, tcardarea.init.off, tcardarea.init.data = areaPool.malloc()
	tcardarea.init.card_w = self.card_w
	for i,kk in ipairs(ca_conf) do tcardarea.init.config[kk] = self.config[kk] end
	tcardarea.init.id = self.ID
	g.input:push(tcardarea.init)
end

local card_set_area = Card.set_card_area
function Card:set_card_area(area, ...)
	tcardarea.emplace.id = area.ID
	tcardarea.emplace.cid = self.ID
	g.input:push(tcardarea.emplace)

	table.insert(area.cards2, self)

	return card_set_area(self, area, ...)
end

local card_remove_area = Card.remove_from_area
function Card:remove_from_area(...)
	if self.area then
		local i = get_index(self.area.cards2, self)
		if not i then error(string.format('Card %s is not in %s', self.ID, self.area.ID)) end
		table.remove(self.area.cards2, i)

		tcardarea.remove.id = self.area.ID
		tcardarea.remove.cid = self.ID
		g.input:push(tcardarea.remove)
	end
	return card_remove_area(self, ...)
end

local area_align = CardArea.align_cards
function CardArea:align_cards()
end

local unext = 0
local uint = 1/30

local update = Game.update
function Game:update(dt)
	if G.TIMERS.REAL > unext or G.TIMERS.REAL < unext - uint * 2 then
		unext = G.TIMERS.REAL + uint
		for i,card in ipairs(G.I.CARD) do
			if card.PM_shr then
				card.PM_shr.ability_order = card.ability and card.ability.order or 0
				card.PM_shr.pinned = not not card.pinned
				card.PM_shr.highlighted = not not card.highlighted
			end
		end
		for i,area in ipairs(G.I.CARDAREA) do
			for j, card in ipairs(area.cards) do
				if (area.config.type == 'deck' or area.config.type == 'discard') and card.facing == 'front' then
					card:flip()
				end
				if area.cards2[j] ~= card then
					area.cards2[j] = card
					tcardarea.sync.id = area.ID
					tcardarea.sync.cid = card.ID
					tcardarea.sync.i = j
					g.input:push(tcardarea.sync)
				end
			end
			area.PM_shr.nosort = not not area.no_sort
			area.PM_shr.card_limit = area.config.card_limit
			area:set_ranks()
		end

	end
	return update(self, dt)
end

function love.handlers.futil_pm_ca_sync(aid, index, cid)
	--- @type any
	local area = g.moveablesById[aid]
	if not area then error('Unknown cardarea ID ' .. aid) end
	--- @type any
	local card = g.moveablesById[cid]
	if not card then error('Unknown card ID ' .. cid) end

	if area == G.play then return end

	local pi = get_index(area.cards, card)
	if not pi then error(string.format('Card %s is not in %s', cid, aid)) end
	area.cards[pi] = area.cards[index]
	area.cards[index] = card

	local pi2 = get_index(area.cards2, card)
	if not pi2 then error(string.format('Card %s is not in %s', cid, aid)) end
	area.cards2[pi2] = area.cards2[index]
	area.cards2[index] = card
end