local g = require("futil.parallel_move.host.init")
local ffi = require("ffi")

local intsize = ffi.sizeof('int')
local function cast(size)
	local data = love.data.newByteData(intsize * (size + 1))
	local d = {
		allocated = size,
		data = data,
		ptr = ffi.cast('int*', data:getFFIPointer()),
		off = 0
	}
	function d:push(v)
		if self.off >= self.allocated then return end
		self.ptr[self.off] = v
		self.off = self.off + 1
		self.ptr[self.off] = 0
	end
	return d
end

local pc = {
	nodesList = cast(1024),
	collisionList = cast(1024),
	drawHash = cast(16384),
	drawHash2 = cast(16384),
	n = 0
}
G.parallelController = pc

local gcp = Controller.get_cursor_collision
function Controller:get_cursor_collision()
end

local sch = Controller.set_cursor_hover
function Controller:set_cursor_hover()
end

local uf = Controller.update_focus
function Controller:update_focus()
end

function add_to_drawhash(obj)
	if pc.n > 1 then return end
	pc.drawHash:push(obj.ID)
end

function reset_drawhash()
	pc.n = pc.n + 1
	if pc.n > 1 then return end
	pc.drawHash.off = 0
	pc.drawHash.ptr[0] = 0
end

g.input:push({
	command = 'ctrl_setbuf',
	n = pc.nodesList.data,
	c = pc.collisionList.data,
	d = pc.drawHash2.data,
	d2 = pc.drawHash.data
})

function love.handlers.futil_pm_ctrl_sync()
	local self = G.CONTROLLER
    self.collision_list = EMPTY(self.collision_list)
    self.nodes_at_cursor = EMPTY(self.nodes_at_cursor)

    if self.COYOTE_FOCUS then return end

    if self.dragging.target then
        self.dragging.target.states.collide.is = true
        self.nodes_at_cursor[#self.nodes_at_cursor+1] = self.dragging.target
        self.collision_list[#self.collision_list+1] = self.dragging.target
    end

	local nl = pc.nodesList.ptr
	while nl[0] ~= 0 do
		table.insert(self.nodes_at_cursor, g.moveablesById[nl[0]])
		nl = nl + 1
	end

	local cl = pc.collisionList.ptr
	while cl[0] ~= 0 do
		table.insert(self.collision_list, g.moveablesById[cl[0]])
		cl = cl + 1
	end

	uf(self)
	sch(self)

	pc.drawHash, pc.drawHash2 = pc.drawHash2, pc.drawHash
	pc.n = 0
end