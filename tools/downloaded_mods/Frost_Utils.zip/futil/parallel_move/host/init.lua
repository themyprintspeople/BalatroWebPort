--- @diagnostic disable: duplicate-set-field

local ffi = require('ffi')
ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/global.h'))))

--- @class futil.PMHost
--- @field state PM.GlobalState
--- @field moveablesById table<any, balatro.Moveable>
local g = {
	input = love.thread.getChannel('futil_pm'),
	thr = love.thread.newThread('futil/parallel_move/worker/init.lua'),
	stateData = love.data.newByteData(assert(ffi.sizeof('struct PM_GlobalState'))),
	moveablesById = setmetatable({}, { __mode = 'v' })
}
g.state = ffi.cast('struct PM_GlobalState *', g.stateData:getFFIPointer()) --- @diagnostic disable-line
g.thr:start(g.input, g.stateData)

g.lowNext = 0
g.lowInterval = 0.1
g.mleak = 0
g.mcount = 0

function g.updateLow()
	if G.TIMERS.REAL < g.lowNext then return end
	g.lowNext = G.TIMERS.REAL + g.lowInterval

	local s = g.state
	s.highlight_h = G.HIGHLIGHT_H
	s.ca_hand_id = G.hand and G.hand.ID or 0
	s.ca_play_id = G.play and G.play.ID or 0
	s.ca_deck_id = G.deck and G.deck.ID or 0
	s.ca_consumable_id = G.consumeables and G.consumeables.ID or 0
	s.reduced_motion = not not G.SETTINGS.reduced_motion
	s.viewing_deck = not not G.view_deck
	s.room_exists = not not G.ROOM
	if G.ROOM then s.room_t = G.ROOM.T end
end

function g.updateState(dt)
	local s = g.state
	g.mleak = s.mleak
	g.mcount = s.mcount

	s.busy = true
	s.frame_update = G.FRAMES.MOVE
	s.frame_draw = G.FRAMES.DRAW + 1
	s.time = G.TIMERS.REAL + dt
	s.paused = G.SETTINGS.paused
	s.state = G.STATE
	s.cursor.x = G.CURSOR.T.x
	s.cursor.y = G.CURSOR.T.y
	s.coyote_focus = not not G.CONTROLLER.COYOTE_FOCUS
	s.dragging_target = G.CONTROLLER.dragging.target and G.CONTROLLER.dragging.target.ID or 0
	g.updateLow()
end

function g.addMoveableToList(m)
	g.moveablesById[m.ID] = m
end

local dt = 0
local update = Game.update
function Game:update(ldt)
	dt = ldt
	return update(self, dt)
end

local updatecmd = { command = 'update' }
local draw = Game.draw
function Game:draw(...)
	if not g.state.busy then
		g.updateState(dt)
		g.input:push(updatecmd)
	end
	return draw(self, ...)
end

--- @class balatro.Game
local G = G
G.parallelMoveable = g

return g
