--- @diagnostic disable: duplicate-set-field

local g = require("futil.parallel_move.host.init")

local ffi = require("ffi")
ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/moveable.h'))))

local function iterable(props)
	for i,v in ipairs(props) do
		props[v] = i
	end

	local function iterator(obj, index)
		index = index == nil and 1 or props[index] + 1
		local k = props[index]
		return k, k and obj[k]
	end
	return {
		__pairs = function (obj)
			return iterator, obj
		end
	}
end

ffi.metatype("struct PM_Vec2_f", iterable({ 'x', 'y' }))
ffi.metatype("struct PM_Vec2_d", iterable({ 'x', 'y' }))
ffi.metatype("struct PM_Pinch", iterable({ 'x', 'y' }))
ffi.metatype("struct PM_Transform", iterable({ 'x', 'y', 'w', 'h', 'r', 'scale' }))
ffi.metatype("struct PM_Velocity", iterable({ 'x', 'y', 'r', 'scale', 'mag' }))
ffi.metatype("struct PM_State", iterable({ 'visible', 'collide', 'focus', 'hover', 'click', 'drag', 'release_on' }))
ffi.metatype("struct PM_Juice", { __index = { handled_elsewhere = false } })

--- @class balatro.Game
local G = G
G.parallelMoveableInit = 0
G.ARGS.T_SWAP = {}

local t = {
	init = { command = 'init' },
	setRole = { command = 'setRole', role = {} },
	setAlignment = { command = 'setAlignment' },
	setAttribute = { command = 'setAttribute' },
	setMid = { command = 'setMid' },
	destroy = { command = 'destroy' },
	juice = { command = 'juice' },
	juiceNew = { command = 'juiceNew' },
	setContainer = { command = 'setContainer' },
	remove = { command = 'remove' },
}

local fieldswap = { 'FRAME', 'pinch', 'shadow_parrallax', 'layered_parallax', 'T', 'VT', 'velocity', 'states', }

local util = require('futil.lib.util')
local moveablePool = util.pooler("struct PM_Moveable")
local juicePool = util.pooler("struct PM_Juice", nil, 1024)

local move_init = Moveable.init
function Moveable:init(...)
	if self.ID then return end

	G.parallelMoveableInit = G.parallelMoveableInit + 1
	move_init(self, ...)
	G.parallelMoveableInit = G.parallelMoveableInit - 1

	self.PM_c, t.init.off, t.init.data = moveablePool.malloc()
	local data = self.PM_c
	data.ID = self.ID
	data.T = self.T
	data.VT = self.T
	if self.created_on_pause then data.created_on_pause = true end
	if self.config.refresh_movement then data.refresh_movement = true end

	for i,kk in ipairs(fieldswap) do
		self[kk] = data[kk]
	end
	self.CT = self.T
	self.alignment.offset = data.alignment_offset
	self.role.offset = data.role_offset

	self.FRAME.DRAW = -1
	self.FRAME.MOVE = -1

	self.states.visible = true
	self.states.hover.can = true
	self.states.click.can = true
	self.states.drag.can = true
	self.states.release_on.can = true

	ffi.gc(self.PM_c, self.destroy)

	t.init.cid = self.container and self.container.ID or 0
	if G.ROOM and self.container == G.ROOM then t.init.cid = -1 end

	g.input:push(t.init)
	g.addMoveableToList(self)
end

local move_cp = Moveable.calculate_parrallax
function Moveable:calculate_parrallax()
	if G.parallelMoveableInit == 0 then return move_cp(self) end
end

local setrole_copyattr = {
	'role_type', 'major', 'xy_bond', 'wh_bond', 'r_bond', 'scale_bond'
}

local move_setrole = Moveable.set_role
function Moveable:set_role(args)
	move_setrole(self, args)

	if args.offset then
		self.role.offset = self.PM_c.role_offset
		self.role.offset.x = args.offset.x
		self.role.offset.y = args.offset.y
	end

	t.setRole.id = self.ID
	for i,kk in ipairs(setrole_copyattr) do
		t.setRole.role[kk] = self.role[kk]
	end
	t.setRole.role.major = self.role.major and self.role.major.ID or nil
	g.input:push(t.setRole)
end

local move_setalign = Moveable.set_alignment
function Moveable:set_alignment(args)
	move_setalign(self, args)

	if args.offset then
		self.alignment.offset = self.PM_c.alignment_offset
		self.alignment.offset.x = args.offset.x
		self.alignment.offset.y = args.offset.y
	end

	t.setAlignment.id = self.ID
	t.setAlignment.type = self.alignment.type
	t.setAlignment.lr_clamp = self.alignment.lr_clamp
	g.input:push(t.setAlignment)
end

local move_juice = Moveable.juice_up
function Moveable:juice_up(...)
	if not self.PM_juice then
		self.PM_juice, t.juiceNew.off, t.juiceNew.data = juicePool.malloc()
		t.juiceNew.id = self.ID
		move_juice(self, ...)
		g.input:push(t.juiceNew)
	else
		t.juice.id = self.ID
		move_juice(self, ...)
		g.input:push(t.juice)
	end
end

local move_set_container = Moveable.set_container
function Moveable:set_container(cont)
	t.setContainer.id = self.ID
	t.setContainer.cid = cont and (G.ROOM and cont == G.ROOM and -1 or cont.ID) or 0
	g.input:push(t.setContainer)

	return move_set_container(self, cont)
end

local move_remove = Moveable.remove
function Moveable:remove()
	t.remove.id = self.ID
	g.input:push(t.remove)
	return move_remove(self)
end

function Moveable:destroy()
	t.destroy.id = self.ID
	g.input:push(t.destroy)
end

function Moveable:setMid(mid, force)
	if not force and self.Mid == mid then return end
	self.Mid = mid

	t.setMid.id = self.ID
	t.setMid.mid = mid.ID
	g.input:push(t.setMid)
end

function Moveable:setAttribute(k, v, force)
	if not force and self[k] == v then return end
	self[k] = v

	t.setAttribute.id = self.ID
	t.setAttribute.k = k
	t.setAttribute.v = v
	g.input:push(t.setAttribute)
end

function Moveable:move() end

local bl_init = Blind.init
function Blind:init(...)
	bl_init(self, ...)
	self:setAttribute('zoom', true, true)
end

local card_init = Card.init
function Card:init(...)
	card_init(self, ...)
	self:setAttribute('zoom', true, true)
end

local sprite_init = Sprite.init
function Sprite:init(...)
	sprite_init(self, ...)
	self:setAttribute('zoom', true, true)
end

local uie_init = UIElement.init
function UIElement:init(...)
	Moveable.init(self)
	self.states.click.can = false
	self.states.drag.can = false
	self.static_rotation = true
	return uie_init(self, ...)
end

function love.handlers.futil_pm_unjuice(id)
	local m = g.moveablesById[id]
	if not m then return end
	m.juice = nil
end
