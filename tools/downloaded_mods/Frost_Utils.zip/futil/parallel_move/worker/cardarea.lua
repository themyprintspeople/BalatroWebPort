local ffi = require("ffi")
local util = require("futil.lib.wutil")
local d = _ext

--- @class balatro.Card
--- @field PM_shr PM.SharedCard
--- @field PM_shr_data love.Data

--- @class balatro.CardArea
--- @field cards2 balatro.Card[]
--- @field PM_shr PM.SharedCardArea
--- @field PM_shr_data love.Data

ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/cardarea.h'))))

util.patchAndLoad("cardarea.lua", {{
	"if card.facing == 'front' then card:flip() end",
	""
}, {
	"if (self == G.hand or self == G.deck or self == G.discard or self == G.play) and G.view_deck and G.view_deck[1] and G.view_deck[1].cards then return end",
	""
}, {
	"for k, card in ipairs%(self%.cards%) do[^\n]*\n%s*card%.rank = k[^\n]*\n%s*end[^\n]*",
	"",
	true
}, {
	"if self%.children%.view_deck then[^\n]*\n[^\n]*\n[^\n]*",
	"",
	true
}, {
	"G.STATE == G.STATES.PLANET_PACK",
	"G.STATE == G.STATES.PLANET_PACK or _ext.state.state == _ext.C.STATES.SMODS_BOOSTER_OPENED",
}, {
	"G.STATES",
	"_ext.C.STATES"
}, {
	"G.SETTINGS.reduced_motion",
	"_ext.state.reduced_motion"
}, {
	"G.HIGHLIGHT_H",
	"_ext.state.highlight_h"
}, {
	".highlighted",
	".PM_shr.highlighted"
}, {
	"G.TIMERS.REAL",
	"_ext.state.time"
}, {
	"G.STATE",
	"_ext.state.state"
}, {
	"self == G.consumeables",
	"self.ID == _ext.state.ca_consumable_id"
}, {
	"self ~= G.consumeables",
	"self.ID ~= _ext.state.ca_consumable_id"
}, {
	"self == G.deck",
	"self.ID == _ext.state.ca_deck_id"
}, {
	".ability.order",
	".PM_shr.ability_order"
}, {
	".pinned",
	".PM_shr.pinned"
}, {
	".sort_id",
	".PM_shr.sort_id"
}, {
	"*self.shuffle_amt",
	"*0"
}, {
	".config.card_limit",
	".PM_shr.card_limit"
}, {
	".config.temp_limit",
	".temp_limit"
}, {
	"G.hand.T.y",
	"self.T.y"
}})

local c_shr_ptr_t = ffi.typeof("struct PM_SharedCard *")
local ca_shr_ptr_t = ffi.typeof("struct PM_SharedCardArea *")

--- @type table<any, balatro.CardArea>
local cardareas = {}
setmetatable(cardareas, { __mode = 'v' })

local function getcindex(area, card)
	local i = get_index(area.cards, card)
	if not i then error(string.format('Card %s is not in %s', card.cid, area.id)) end

	local i2 = get_index(area.cards2, card)
	if not i2 then error(string.format('Card %s is not in %s', card.cid, area.id)) end

	return i, i2
end

--- @return balatro.CardArea
--- @return balatro.Card
local function getrefs(msg)
	return d.getMoveable(msg.id, nil, 'cardarea'), d.getMoveable(msg.cid, nil, 'card') --- @diagnostic disable-line
end

function d.cmds.card_init(msg)
	--- @type any
	local card = d.getMoveable(msg.id)

	card.PM_shr = c_shr_ptr_t(msg.data:getFFIPointer())[msg.off]
	card.PM_shr_data = msg.data
	card.discard_pos = card.PM_shr.discard_pos
end

function d.cmds.cardarea_init(msg)
	--- @type any
	local ca = d.getMoveable(msg.id)

	ca.card_w = msg.card_w
	ca.config = msg.config
	ca.cards2 = setmetatable({}, { __mode = 'v' })
	ca.cards = {}
	ca.PM_shr = ca_shr_ptr_t(msg.data:getFFIPointer())[msg.off]
	ca.PM_shr_data = msg.data

	cardareas[ca.ID] = ca
end

function d.cmds.cardarea_addcard(msg)
	local area, card = getrefs(msg)

	if msg.front then
		table.insert(area.cards, 1, card)
		table.insert(area.cards2, 1, card)
	else
		table.insert(area.cards, card)
		table.insert(area.cards2, card)
	end
end

function d.cmds.cardarea_removecard(msg)
	local area, card = getrefs(msg)

	local i, i2 = getcindex(area, card)
	table.remove(area.cards, i)
	table.remove(area.cards2, i2)
end

function d.cmds.cardarea_synccard(msg)
	local area, card = getrefs(msg)

	local i, i2 = getcindex(area, card)
	area.cards[i] = area.cards[msg.i]
	area.cards[msg.i] = card
	area.cards2[i2] = area.cards2[msg.i]
	area.cards2[msg.i] = card
end


local unext = 0
local uint = 0.05

--- @param area balatro.CardArea
local function updateArea(area)
	if area.PM_shr.nosort then return end

	area.temp_limit = math.max(area.PM_shr.card_limit, #area.cards) --- @diagnostic disable-line
	CardArea.align_cards(area)
	for j,card in ipairs(area.cards) do
		if area.cards2[j] ~= card then
			area.cards2[j] = card
			love.event.push('futil_pm_ca_sync', area.ID, j, card.ID) --- @diagnostic disable-line
		end
	end
end

table.insert(d.updates, function()
	if not (d.state.time > unext or d.state.time < unext - 1.1 * uint) then return end
	unext = d.state.time + uint
	for i,area in pairs(cardareas) do
		if not area.REMOVED then
			updateArea(area)
		end
	end
end)
