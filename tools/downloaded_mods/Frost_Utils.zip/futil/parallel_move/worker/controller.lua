--- @diagnostic disable: duplicate-set-field
local ffi = require("ffi")

local d = _ext

local unext = 0
local uint = 1/30
local uinti = 1/5

local intsize = ffi.sizeof('int')
--- @param data love.ByteData
local function cast(data)
	local d = {
		allocated = math.floor(data:getSize() / intsize) - 1,
		data = data,
		ptr = ffi.cast('int*', data:getFFIPointer()),
		off = 0
	}
	function d:push(v)
		if self.off >= self.allocated then return end
		self.ptr[self.off] = v
		self.off = self.off + 1
	end
	return d
end

local pcx = 0
local pcy = 0
local shared
table.insert(d.updates, function()
	local interval = pcx == d.state.cursor.x and pcy == d.state.cursor.y and uinti or uint
	if not (shared and not d.state.coyote_focus and (d.state.time > unext or d.state.time < unext - 2 * interval)) then return end
	unext = d.state.time + interval

	local pi = shared.collisionList.ptr
	local dragging = d.state.dragging_target
	while pi[0] ~= 0 do
		local moveable = d.moveables[pi[0]]
		if moveable and not moveable.REMOVED and dragging ~= moveable.ID then
			moveable.states.collide.is = false
		end
		pi = pi + 1
	end

	shared.nodesList.off = 0
	shared.collisionList.off = 0

	pi = 0
	while shared.drawHash.ptr[pi] ~= 0 do pi = pi + 1 end
	for i=pi, 0, -1 do
		local moveable = d.moveables[shared.drawHash.ptr[i]]
		if moveable and not moveable.REMOVED and moveable:collides_with_point(d.state.cursor) then
			shared.nodesList:push(moveable.ID)
			if moveable.states.collide.can then
				moveable.states.collide.is = true
				shared.collisionList:push(moveable.ID)
			end
		end
	end

	shared.nodesList.ptr[shared.nodesList.off] = 0
	shared.collisionList.ptr[shared.collisionList.off] = 0

	love.event.push('futil_pm_ctrl_sync') --- @diagnostic disable-line
	shared.drawHash, shared.drawHash2 = shared.drawHash2, shared.drawHash
	pcx, pcy = d.state.cursor.x, d.state.cursor.y
end)

function d.cmds.ctrl_setbuf(msg)
	shared = {
		nodesList = cast(msg.n),
		collisionList = cast(msg.c),
		drawHash = cast(msg.d),
		drawHash2 = cast(msg.d2)
	}
end