--- @type love.Channel, love.Data
local input, sharedData = ...
local ffi = require("ffi")
require("love.filesystem")
require("love.event")

local preload = require("futil.config.preload")
ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/global.h'))))

--- @class futil.PMWorker
--- @field state PM.GlobalState
--- @field moveables table<any, balatro.Moveable>
--- @field cmds table<string, fun(msg)>
_ext = {
	stateData = sharedData,
	state = ffi.cast("struct PM_GlobalState *", sharedData:getFFIPointer()), --- @diagnostic disable-line
	moveables = {},
	cmds = {},
	input = input
}

function _ext.getMoveable(id, desc, type)
	local e = id == -1 and _ext.virtroom or _ext.moveables[id]
	if not e then error(string.format('Unknown %s %s ID %s', desc or '', type or 'moveable', id)) end
	if e.REMOVED then
		print(string.format('futil/parallel_ui: moveable %d is still referenced after removed', id))
	end
	return e
end

--- @type fun()[]
_ext.updates = {}

_ext.virtroom = { T = _ext.state.room_t }

_ext.C = {
	exp_xy = 0,
	exp_max_vel = 0,
	exp_scale = 0,
	exp_r = 0,
}

_ext.C.STATES = {
	SELECTING_HAND = 1,
	HAND_PLAYED = 2,
	DRAW_TO_HAND = 3,
	GAME_OVER = 4,
	SHOP = 5,
	PLAY_TAROT = 6,
	BLIND_SELECT = 7,
	ROUND_EVAL = 8,
	TAROT_PACK = 9,
	PLANET_PACK = 10,
	MENU = 11,
	TUTORIAL = 12,
	SPLASH = 13,--DO NOT CHANGE, this has a dependency in the SOUND_MANAGER
	SANDBOX = 14,
	SPECTRAL_PACK = 15,
	DEMO_CTA = 16,
	STANDARD_PACK = 17,
	BUFFOON_PACK = 18,
	NEW_ROUND = 19,
	SMODS_BOOSTER_OPENED = 999
}

local util = require("futil.lib.wutil")
util.patchAndLoad("engine/object.lua", {})
util.patchAndLoad("engine/node.lua", {{
	"G.COLLISION_BUFFER",
	"0.05"
}})

function EMPTY(t)
	if not t then return {} end
	for k, v in pairs(t) do
		t[k] = nil
	end
	return t
end

function get_index(t, val)
    local index = nil
    for i, v in pairs(t) do
        if v == val then
          index = i
        end
    end
    return index
end

function point_translate(_T, delta)
  _T.x = (_T.x + delta.x) or 0
  _T.y = (_T.y + delta.y) or 0
end

function point_rotate(_T, angle)
  local _cos, _sin, _ox, _oy = math.cos(angle+math.pi/2), math.sin(angle+math.pi/2), _T.x , _T.y
  _T.x = -_oy*_cos + _ox*_sin
  _T.y = _oy*_sin + _ox*_cos
end

require("futil.parallel_move.worker.moveable")
if preload.config.parallel_align then
	require("futil.parallel_move.worker.cardarea")
end
if preload.config.parallel_controller then
	require("futil.parallel_move.worker.controller")
end

function _ext.cmds.update()
	for i,v in ipairs(_ext.updates) do v() end
	_ext.state.busy = false
end

while true do
	local msg = _ext.input:demand()
	if msg.command == "stop" then break end
	local f = _ext.cmds[msg.command]
	if f then
		f(msg)
	else
		error('Unknown command ' .. msg.command)
	end
end