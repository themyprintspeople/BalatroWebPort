local ffi = require("ffi")
local util = require("futil.lib.wutil")
local d = _ext

--- @class balatro.Moveable
--- @field PM_c PM.Moveable
--- @field PM_juice PM.Juice
--- @field PM_data love.Data
--- @field PM_juice_data love.Data

ffi.cdef((assert(love.filesystem.read('futil/parallel_move/def/moveable.h'))))

util.patchAndLoad("engine/moveable.lua", {{
	"G.TIMERS.REAL",
	"_ext.state.time"
}, {
	"G.FRAMES.MOVE",
	"_ext.state.frame_update"
}, {
	"G.SETTINGS.paused",
	"_ext.state.paused"
}, {
	"G.ROOM.T.w",
	"_ext.state.room_t.w"
}, {
	"G.ROOM",
	"_ext.state.room_exists"
}, {
	"G.exp_times.xy",
	"_ext.C.exp_xy"
}, {
	"G.exp_times.max_vel",
	"_ext.C.exp_max_vel"
}, {
	"G.exp_times.scale",
	"_ext.C.exp_scale"
}, {
	"G.exp_times.r",
	"_ext.C.exp_r"
}, {
	"FRAME.MAJOR",
	"cur_major"
}, {
	"FRAME.OLD_MAJOR",
	"old_major"
}, {
	".config.refresh_movement or",
	".refresh_movement or"
}, {
	".juice = nil",
	":unjuice()"
}, {
	"or (G.REFRESH_FRAME_MAJOR_CACHE)",
	""
}, {
	"and not self.juice.handled_elsewhere",
	""
}, {
	"self.pinch = major_tab.pinch",
	"self.pinch.x, self.pinch.y = major_tab.pinch.x, major_tab.pinch.y"
}, {
	"self.shadow_parrallax = major_tab.shadow_parrallax",
	"self.shadow_parrallax.x, self.shadow_parrallax.y = major_tab.shadow_parrallax.x, major_tab.shadow_parrallax.y"
}})

function Moveable:unjuice()
	self.juice = nil
	love.event.push('futil_pm_unjuice', self.ID) --- @diagnostic disable-line
end

local moveableFields = {
	'FRAME',
	'pinch',
	'shadow_parrallax',
	'layered_parallax',
	'T',
	'VT',
	'velocity',
	'states',
	'ID',
	'created_on_pause',
	'refresh_movement',
}
local moveable_ptr_t = ffi.typeof("struct PM_Moveable *")
local juice_ptr_t = ffi.typeof("struct PM_Juice *")

function d.cmds.init(msg)
	--- @type PM.Moveable
	local data = moveable_ptr_t(msg.data:getFFIPointer())[msg.off]
	--- @type balatro.Moveable
	local moveable = setmetatable({}, Moveable) --- @diagnostic disable-line

	for i,v in ipairs(moveableFields) do moveable[v] = data[v] end

	moveable.role = {
        role_type = 'Major',
        offset = data.role_offset,
        major = nil,
        draw_major = nil,
        xy_bond = 'Strong',
        wh_bond = 'Strong',
        r_bond = 'Strong',
        scale_bond = 'Strong'
    }
    moveable.alignment = {
        type = 'a',
        offset = data.alignment_offset,
        prev_type = '',
        prev_offset = {x = 0, y = 0},
    }
	moveable.ARGS = {}
	moveable.Mid = moveable

	moveable:calculate_parrallax()

	moveable.PM_c = data
	moveable.PM_data = msg.data

	moveable.container = msg.cid == -1 and d.virtroom or d.moveables[msg.cid]

	d.moveables[data.ID] = moveable
end
local setrole_copyattr = {
	'role_type', 'major', 'xy_bond', 'wh_bond', 'r_bond', 'scale_bond'
}

function d.cmds.setRole(msg)
	local m = d.getMoveable(msg.id)
	for i,kk in ipairs(setrole_copyattr) do
		if msg.role[kk] then
			m.role[kk] = msg.role[kk]
		end
	end
	if msg.role.role_type == 'Major' then
		m.role.major = nil
	elseif msg.role.major then
		m.role.major = d.getMoveable(msg.role.major, 'major')
	end
	--print('align', msg.id, msg.type)
end
function d.cmds.setAlignment(msg)
	local m = d.getMoveable(msg.id)
	m.alignment.type = msg.type
	m.alignment.lr_clamp = msg.lr_clamp
	--print('align', msg.id, msg.type)
end
function d.cmds.setAttribute(msg)
	local m = d.getMoveable(msg.id)
	m[msg.k] = msg.v
	--print('attr', msg.id, msg.k, msg.v)
end
function d.cmds.setMid(msg)
	local m = d.getMoveable(msg.id)
	m.Mid = d.getMoveable(msg.mid, 'Mid')
	--print('mid', msg.id, msg.mid)
end
function d.cmds.juiceNew(msg)
	local m = d.getMoveable(msg.id)
	--- @type PM.Juice
	local data = juice_ptr_t(msg.data:getFFIPointer())[msg.off]
	m.PM_juice = data
	m.PM_juice_data = msg.data
	m.juice = m.PM_juice --- @diagnostic disable-line
end
function d.cmds.juice(msg)
	local m = d.getMoveable(msg.id)
	if not m.PM_juice then error('No juice data for moveable ID ' .. msg.id) end
	m.juice = m.PM_juice --- @diagnostic disable-line
end
function d.cmds.destroy(msg)
	d.moveables[msg.id] = nil
end
function d.cmds.remove(msg)
	local m = d.moveables[msg.id]
	if m then m.REMOVED = true end
end
function d.cmds.setContainer(msg)
	local m = d.getMoveable(msg.id)
	m.container = d.getMoveable(msg.cid)
end

local ptime = 0
local ml = 0
local mc = 0
table.insert(d.updates, function(msg)
	local dt = math.max(math.min(_ext.state.time - ptime, 0.033), 0.0001)
	ptime = _ext.state.time
	_ext.C.exp_xy = math.exp(-50*dt)
	_ext.C.exp_scale = math.exp(-60*dt)
	_ext.C.exp_r = math.exp(-190*dt)
	_ext.C.exp_max_vel = 70*math.min(1/20, dt)

	for k,moveable in pairs(_ext.moveables) do
		mc = mc + 1
		if not moveable.REMOVED then
			moveable:move(dt)
		else
			ml = ml + 1
		end
	end

	_ext.state.mcount = mc
	_ext.state.mleak = ml
	ml = 0
	mc = 0
end)