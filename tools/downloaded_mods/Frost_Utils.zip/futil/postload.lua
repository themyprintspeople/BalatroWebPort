require("futil.config.initstate").init()

require("futil.optimization.vanilla")

if G.SETTINGS.futil.ev2.enable then
	require("futil.ev2.migrator"):tov2()
end

local settings = G.SETTINGS.futil
if settings.jit == 2 and not jit.status() then
	jit.on()
	print('JIT turned on')
elseif settings.jit == 3 and jit.status() then
	jit.off()
	print('JIT turned off')
end

local init = Event.init
function Event:init(opts)
	self.use_lln = opts.lln
	return init(self, opts)
end