local qc = require("futil.config.preload")
local modules = {
	'joystick',
	'math',
	'touch',
	'physics',
	'video',
}

local conf = love.conf
local love2 = love
function love2.conf(w)
	conf(w)
	for i,v in ipairs(modules) do
		if qc.config['disable_'..v] then
			print(string.format('futil/ql: love.%s', v))
			w.modules[v] = false
		end
	end
end