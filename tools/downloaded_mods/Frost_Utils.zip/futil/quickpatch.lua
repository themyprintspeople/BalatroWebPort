futil_require = require

local lovely = require"lovely"
local preload = require("futil.config.preload")

local ffi = require("ffi")
ffi.cdef[[
int PHYSFS_mount(const char* dir, const char* mountPoint, int appendToPath);
int PHYSFS_unmount(const char* dir);
]]
local C = (pcall(function() return ffi.C.PHYSFS_mount end) and ffi.C or ffi.load("love"))

require("love.timer")
require("love.thread")
require("love.system")

-- detect for love2d-phantom
if love.filesystem.getInfo('phantom/lib/inspect.lua') then
	print("futil/qpatch: ignoring, phantom is present")
	return
end

local patchIn = love.thread.newChannel()
local patchOut = love.thread.newChannel()
local fsIn = love.thread.newChannel()

-- asynchronous i/o
local afscontent = love.filesystem.newFileData([[
local input, n = ...
while true do
	local msg = input:demand()
	if not msg then
		n = n - 1
		if n == 0 then break end
	else
		love.filesystem.write(msg[1], msg[2])
	end
end

print('futil/qp: done fs')
]], "futil/virt/qpatch/afs.lua")

local afsthr = love.thread.newThread(afscontent)

-- asynchronous patcher
local workercontent = love.filesystem.newFileData([[
local input, output, fsIn, globalhit, id = ...
require("love.filesystem")
require("love.timer")

local tn = 0
local tt = 0

while true do
	local msg = input:demand()
	if not msg then break end

	local t = love.timer.getTime()
	local t2

	local content = assert(love.filesystem.read(msg))
	local hash = love.data.hash("sha256", content)
	local cfile = love.data.encode("string", "hex", love.data.hash("md5", msg))
	local cpath = "futil_lovelycache/"..cfile
	local chash = "futil_lovelycache/"..cfile..".hash"

	local cc = globalhit and hash == love.filesystem.read(chash)
		and love.filesystem.read(cpath)
		or nil

	if not cc then
		print(string.format('futil/qp[%d]: patching %s', id, msg))
		cc = string.dump(assert(loadstring(content, "@"..msg)))
		t2 = love.timer.getTime()
		print(string.format('futil/qp[%d]: patched %s in %.1fms', id, msg, (t2 - t)*1000))

		fsIn:push({cpath, cc})
		fsIn:push({chash, hash})
	else
		t2 = love.timer.getTime()
		print(string.format('futil/qp[%d]: using cached patch %s', id, msg))
	end

	output:push({ command = "out", file = msg, content = cc })

	tn = tn + 1
	tt = tt + t2 - t
end

print(string.format('futil/qp[%d]: done worker (%d patches in %.1fms)', id, tn, tt * 1000))
fsIn:push(nil)
output:push({ command = "done", id = id })
]], "futil/virt/qpatch.lua")

-- test if thread patching is ok
local patch_thread = false
do
local stc = love.thread.newChannel()
local st = love.thread.newThread([[
local t = ...
assert(loadstring("a = 1", "@futil/virt/qpatch/test.lua"))()
t:push(a == 2)
]])
st:start(stc)
patch_thread = stc:demand(0.5)
end

assert(C.PHYSFS_mount(lovely.mod_dir, '__mods', 0) ~= 0, 'Failed to mount mods direcotry ' .. lovely.mod_dir)

-- hash patch
local patchfiles = {}
local function iterpatchfiles(base, depth)
	if not love.filesystem.getInfo(base..'/.lovelyignore') then
		local s1 = love.filesystem.getInfo(base..'/lovely.toml')
		if s1 and s1.type == "file" then
			table.insert(patchfiles, base)
			table.insert(patchfiles, '\n')
			table.insert(patchfiles, s1.modtime)
		end

		local litems = love.filesystem.getDirectoryItems(base..'/lovely')
		for i, name in ipairs(litems) do
			local litem = love.filesystem.getInfo(base..'/lovely/'..name)
			if name:sub(-5, -1) == ".toml" and litem.type == "file" then
				table.insert(patchfiles, base)
				table.insert(patchfiles, '\n')
				table.insert(patchfiles, name)
				table.insert(patchfiles, litem.modtime)
			end
		end
	end

	if depth == 0 then return end

	local items = love.filesystem.getDirectoryItems(base)
	for i,name in ipairs(items) do
		local sub = base..'/'..name
		local item = love.filesystem.getInfo(sub)
		if item.type == "directory" then
			iterpatchfiles(sub, depth-1)
		end
	end
end
iterpatchfiles('__mods', 2)
assert(C.PHYSFS_unmount(lovely.mod_dir) ~= 0, 'Failed to unmount mods direcotry ' .. lovely.mod_dir)

local rawhash = table.concat(patchfiles)
local hash = love.data.hash("sha256", rawhash)
local prevhash = preload.config.force_cache_miss and '' or love.filesystem.read("futil_lovelycache/hash")

if hash ~= prevhash then
	print("futil/qp: refreshing patch")
end

-- spawn threads

--- @type love.Thread[]
local workers = {}
if patch_thread then
	local workerThreads = math.min(love.system.getProcessorCount(), hash == prevhash and 1 or 6)
	afsthr:start(fsIn, workerThreads)
	for i=1, workerThreads do
		local t = love.thread.newThread(workercontent)
		workers[i] = t
		t:start(patchIn, patchOut, fsIn, hash == prevhash, i)
	end
	print(string.format('futil/qp: using %d threads', workerThreads))
else
	afsthr:start(fsIn, 1)
	print(string.format('futil/qp: using main thread only'))
end

love.filesystem.createDirectory("futil_lovelycache")
fsIn:push({"futil_lovelycache/hash", hash})

-- patching

local caches = {}
local files = {
	"card.lua",
	"functions/UI_definitions.lua",
	"functions/common_events.lua",
	"game.lua",
	"functions/button_callbacks.lua",
	"functions/misc_functions.lua",
	"functions/state_events.lua",
	"blind.lua",

	"back.lua",
	"card_character.lua",
	"cardarea.lua",
	"tag.lua",
	"functions/state_events.lua",
	"engine/text.lua",
	"engine/ui.lua",
	"engine/controller.lua",
	"engine/string_packer.lua",
	"engine/event.lua",
	"engine/node.lua",
	"engine/moveable.lua",
}
for i, file in ipairs(files) do
	if patch_thread then
		patchIn:push(file)
		caches[file] = false
		caches[file:sub(1, -5)] = false
	else
		local content = assert(love.filesystem.read(file))
		local hash = love.data.hash("sha256", content)
		local cfile = love.data.encode("string", "hex", love.data.hash("md5", file))
		local cpath = "futil_lovelycache/"..cfile
		local chash = "futil_lovelycache/"..cfile..".hash"

		local cc = hash == prevhash and hash == love.filesystem.read(chash)
			and love.filesystem.read(cpath)
			or nil

		if not cc then
			local t = love.timer.getTime()
			cc = string.dump(assert(loadstring(content, "@"..file)))
			print(string.format('futil/qp: patched %s in %.1fms', file, (love.timer.getTime() - t)*1000))

			fsIn:push({cpath, cc})
			fsIn:push({chash, hash})
		else
			print('futil/qp: using cached patch', file)
		end

		caches[file] = cc
		caches[file:sub(1, -5)] = cc
	end
end

if patch_thread then
	for i=1, #workers do
		patchIn:push(nil)
	end
else
	fsIn:push(nil)
end

local function waiter(file)
	while true do
		if caches[file] and patchOut:getCount() == 0 then return end

		local out = patchOut:demand(0.1)
		if out then
			if out.command == "out" then
				caches[out.file] = out.content
				caches[out.file:sub(1, -5)] = out.content
			elseif out.command == "done" then
				workers[out.id] = nil
			end
		else
			local has = false
			for i, worker in pairs(workers) do
				has = true
				assert(worker:isRunning(), worker:getError() or 'worker stopped')
			end
			assert(has, 'no running workers')
		end
	end
end

local fr
fr = love.timer.getTime()
local tw = 0

function futil_require(name)
	if fr then
		print(string.format('futil/qp: first require in %.1fms', (love.timer.getTime() - fr) * 1000))
		fr = nil
	end
	if type(name) ~= "string" then
		return require(name)
	end
	if package.loaded[name] then
		print(string.format('futil/qp: already loaded %s', name))
		return package.loaded[name]
	end
	local c = caches[name]
	if c == false then
		print(string.format('futil/qp: waiting %s', name))
		local t = love.timer.getTime()
		waiter(name)
		c = caches[name]
		t = love.timer.getTime() - t
		tw = tw + t
		print(string.format('futil/qp: waited %s in %.1fms (total %.1fms)', name, t * 1000, tw * 1000))
	elseif not c then
		return require(name)
	end
	package.loaded[name] = assert(loadstring(c, "@cached:"..name))() or true
	return package.loaded[name]
end

return { files = files }