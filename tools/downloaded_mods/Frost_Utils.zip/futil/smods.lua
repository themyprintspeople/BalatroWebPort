local futil = assert(SMODS.current_mod, 'SMODS too old (missing SMODS.current_mod)')
assert(_mod_dir_frostutil, string.format("Frost's Utils is nested.\nPath: %s\nMods directory: %s", futil.path, require"lovely".mod_dir))

local preload = require("futil.config.preload")

local icon = SMODS.Atlas{
	key = "modicon",
	path = "icon.png",
	px = 32,
	py = 32
}

futil.config_tab = G.UIDEF.futil_config
futil.extra_tabs = G.UIDEF.futil_extra_tabs
futil.debug_info = {}

local disableds = {}
for i,v in ipairs({ 'joystick', 'math', 'physics', 'touch', 'video', }) do
	if preload.config['disable_'..v] then
		table.insert(disableds, v)
	end
end

if #disableds ~= 0 then
	futil.debug_info.Disabled_Modules = table.concat(disableds, ', ')
end
if preload.config.parallel_move then
	futil.debug_info.Parallel_UI = 'Active'
end
if preload.config.parallel_align then
	futil.debug_info.Parallel_Card_Align = 'Active'
end
if preload.config.parallel_controller then
	futil.debug_info.Parallel_Controller = 'Active'
end
